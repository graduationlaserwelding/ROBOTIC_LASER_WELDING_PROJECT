"""
main.py
=======
Tüm pipeline'ı çalıştırır:

    geometry_output_X.json
        → EdgeGraph
            → PathFinder  (tüm zincirler)
                → Classifier  (düzlem + skor)
                    → JSON çıktısı + konsol özeti

Kullanım:
    python main.py                          # varsayılan: geometry_output_5.json
    python main.py my_part.json             # özel dosya
    python main.py my_part.json --min-score 50
    python main.py my_part.json --closed-only
"""

from __future__ import annotations
import json
import sys
import argparse
from pathlib import Path
from typing import Optional, List

from geometry_models import load_edges_from_geometry_json
from edge_graph import EdgeGraph
from path_finder import PathFinder
from path_classifier import (
    classify_candidates,
    filter_by_min_score,
    filter_closed_only,
    AnnotatedPath,
)


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

def run_pipeline(geometry_json_path: str,
                 min_score: int = 0,
                 closed_only: bool = False,
                 output_path: Optional[str] = None) -> list[AnnotatedPath]:
    """
    Ana pipeline. AnnotatedPath listesi döndürür.
    """

    # ---- 1. JSON yükle ---- #
    print(f"\n[1/5] Geometri yükleniyor: {geometry_json_path}")
    with open(geometry_json_path, "r", encoding="utf-8") as f:
        geometry_data = json.load(f)

    doc_name = geometry_data.get("document_name", "?")
    body_count = geometry_data.get("body_count", 0)
    print(f"      Dosya: {doc_name}  |  Body sayısı: {body_count}")

    # ---- 2. Edge nesneleri oluştur ---- #
    print("[2/5] Edge nesneleri oluşturuluyor...")
    edges = load_edges_from_geometry_json(geometry_data)
    print(f"      Toplam edge: {len(edges)}")

    # ---- 3. Graph kur ---- #
    print("[3/5] EdgeGraph kuruluyor...")
    graph = EdgeGraph.from_edges(edges)
    graph.print_summary()

    # ---- 4. Patika adayları bul ---- #
    print("[4/5] Patika adayları aranıyor...")
    finder = PathFinder(graph)
    candidates = finder.find_all()
    print(f"      Bulunan toplam aday: {len(candidates)}")

    # ---- 5. Sınıflandır ve skorla ---- #
    print("[5/5] Sınıflandırma ve skorlama...")
    annotated = classify_candidates(candidates)

    # ---- Filtrele ---- #
    if closed_only:
        annotated = filter_closed_only(annotated)
        print(f"      Filtre (closed_only): {len(annotated)} path kaldı")
    if min_score > 0:
        annotated = filter_by_min_score(annotated, min_score)
        print(f"      Filtre (min_score={min_score}): {len(annotated)} path kaldı")

    # ---- Konsol özeti ---- #
    _print_results(annotated)

    # ---- JSON kaydet ---- #
    out_path = output_path or _default_output_path(geometry_json_path)
    result_dicts = [a.to_dict() for a in annotated]
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result_dicts, f, indent=2, ensure_ascii=False)
    print(f"\nSonuçlar kaydedildi: {out_path}")

    return annotated


# ---------------------------------------------------------------------------
# Konsol çıktısı
# ---------------------------------------------------------------------------

def _print_results(paths: list[AnnotatedPath]):
    print("\n" + "=" * 65)
    print(f"  BULUNAN PATİKALAR ({len(paths)} adet)")
    print("=" * 65)

    if not paths:
        print("  (Hiç patika bulunamadı)")
        return

    for ap in paths:
        plane_str = (f"{ap.plane_axis}={ap.plane_value}"
                     if ap.plane_value is not None else str(ap.plane_axis))

        status = "●" if ap.is_closed else "○"
        print(f"\n  {status} Path #{ap.path_id:03d}  "
              f"[skor:{ap.score:3d}]  {ap.path_kind}")
        print(f"     Segment: {ap.segment_count}  |  "
              f"Uzunluk: {ap.total_length:.4f}  |  "
              f"Düzlem: {plane_str}")
        print(f"     Tipler: {ap.geom_types}")
        print(f"     Edge indeksleri: {ap.candidate.edge_indices}")
        if ap.notes:
            print(f"     Notlar: {', '.join(ap.notes)}")

    # --- Özet istatistik --- #
    closed = sum(1 for p in paths if p.is_closed)
    open_  = len(paths) - closed
    print("\n" + "-" * 65)
    print(f"  Kapalı: {closed}   Açık: {open_}   Toplam: {len(paths)}")

    # Düzlem dağılımı
    from collections import Counter
    plane_dist = Counter(p.plane_axis for p in paths)
    print(f"  Düzlem dağılımı: {dict(plane_dist)}")
    print("=" * 65 + "\n")


# ---------------------------------------------------------------------------
# Çıktı dosyası adı
# ---------------------------------------------------------------------------

def _default_output_path(input_path: str) -> str:
    p = Path(input_path)
    return str(p.parent / (p.stem + "_paths.json"))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="CAD geometrisinden patika adaylarını tespit eder."
    )
    parser.add_argument(
        "geometry_json",
        nargs="?",
        default="geometry_output.json",
        help="Inventor'dan çıkarılan geometry JSON dosyası",
    )
    parser.add_argument(
        "--min-score",
        type=int,
        default=0,
        help="Minimum skor filtresi (0-100)",
    )
    parser.add_argument(
        "--closed-only",
        action="store_true",
        help="Sadece kapalı patikalari göster",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Çıktı JSON dosyası (varsayılan: input_paths.json)",
    )

    args = parser.parse_args()

    try:
        run_pipeline(
            geometry_json_path=args.geometry_json,
            min_score=args.min_score,
            closed_only=args.closed_only,
            output_path=args.output,
        )
    except FileNotFoundError:
        print(f"\nHATA: Dosya bulunamadı: {args.geometry_json}")
        print("\nÇözüm — önce Inventor'dan geometriyi çekin:")
        print("  1. Inventor'ı açın ve parçanızı yükleyin")
        print("  2. python inventor_extractor.py")
        print(f"  3. python main.py geometry_output.json")
        sys.exit(1)
    except Exception as e:
        print(f"HATA: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
