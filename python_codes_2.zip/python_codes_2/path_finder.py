"""
path_finder.py
==============
Düzlem bazlı gruplama + vertex zincirleme ile tüm patika adaylarını bulur.

Ana fikir:
    Her edge birden fazla düzleme ait olabilir (ör: hem x=6.44 hem y=0.0).
    Öncelik sırası: y > z > x (levha geometrilerinde ana yüzeyler genellikle y'de)
    Bu sayede loop kenarları doğru gruba girer, köşe edge'leri ise
    kendi grubunda (x veya z) kalır.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import List, Set, Dict, Optional, Tuple
import math

from geometry_models import BaseEdge, LineSegmentEdge, ArcEdge
from edge_graph import EdgeGraph

PLANE_TOL = 1e-4
PLANE_PRIORITY = {"y": 0, "z": 1, "x": 2}   # küçük = yüksek öncelik


# ---------------------------------------------------------------------------
# PathCandidate
# ---------------------------------------------------------------------------

@dataclass
class PathCandidate:
    segments:  List[BaseEdge]
    is_closed: bool
    path_kind: str
    path_id:   int = 0

    @property
    def segment_count(self): return len(self.segments)

    @property
    def total_length(self):
        return round(sum(_seg_len(s) for s in self.segments), 6)

    @property
    def geom_types(self):
        return list(dict.fromkeys(s.geom_type for s in self.segments))

    @property
    def edge_indices(self):
        return [s.edge_index for s in self.segments]

    def to_dict(self):
        return {
            "path_id":       self.path_id,
            "path_kind":     self.path_kind,
            "is_closed":     self.is_closed,
            "segment_count": self.segment_count,
            "total_length":  self.total_length,
            "geom_types":    self.geom_types,
            "edge_indices":  self.edge_indices,
            "segments":      [s.to_dict() for s in self.segments],
        }

    def __repr__(self):
        return (f"PathCandidate(id={self.path_id}, kind={self.path_kind}, "
                f"closed={self.is_closed}, segs={self.segment_count}, "
                f"len={self.total_length}, types={self.geom_types})")


def _seg_len(seg):
    if isinstance(seg, LineSegmentEdge) and seg.length is not None:
        return seg.length
    if isinstance(seg, ArcEdge) and seg.arc_length is not None:
        return seg.arc_length
    circ = getattr(seg, "circumference", None)
    return circ if circ else 0.0


# ---------------------------------------------------------------------------
# Düzlem tespiti — TÜM uygun düzlemler
# ---------------------------------------------------------------------------

def _all_planes(seg: BaseEdge) -> List[Tuple[str, float]]:
    """Edge'in ait olduğu tüm koordinat düzlemlerini döndürür."""
    planes = []

    # Arc/Circle için normal vektörü
    normal = getattr(seg, "normal", None)
    center = getattr(seg, "center", None)
    if normal and center:
        nx, ny, nz = normal
        cx, cy, cz = center
        if abs(abs(nx)-1.0) < PLANE_TOL: planes.append(("x", round(cx,6)))
        if abs(abs(ny)-1.0) < PLANE_TOL: planes.append(("y", round(cy,6)))
        if abs(abs(nz)-1.0) < PLANE_TOL: planes.append(("z", round(cz,6)))
        return planes

    # LineSegment için uç noktalar
    sp = seg.start_point
    ep = seg.end_point
    if sp and ep:
        if abs(sp[0]-ep[0]) < PLANE_TOL: planes.append(("x", round(sp[0],6)))
        if abs(sp[1]-ep[1]) < PLANE_TOL: planes.append(("y", round(sp[1],6)))
        if abs(sp[2]-ep[2]) < PLANE_TOL: planes.append(("z", round(sp[2],6)))

    return planes


def _primary_plane(seg: BaseEdge) -> Optional[Tuple[str, float]]:
    """
    Edge'in birincil düzlemini döndürür.
    Birden fazla düzlem varsa öncelik sırasına göre seçer: y > z > x
    """
    planes = _all_planes(seg)
    if not planes:
        return None
    return min(planes, key=lambda p: PLANE_PRIORITY.get(p[0], 99))


# ---------------------------------------------------------------------------
# PathFinder
# ---------------------------------------------------------------------------

class PathFinder:
    def __init__(self, graph: EdgeGraph):
        self.graph    = graph
        self._used    = set()
        self._counter = 0

    def find_all(self) -> List[PathCandidate]:
        results = []

        # 1. Kendi başına kapalı (Circle vb.)
        for edge in self.graph.isolated_closed:
            results.append(PathCandidate(
                segments=[edge], is_closed=True,
                path_kind="isolated_closed", path_id=self._nid(),
            ))
            self._used.add(edge.edge_index)

        # 2. Kalan edge'leri birincil düzleme göre grupla
        plane_groups: Dict = {}
        for eidx, edge in self.graph.edges.items():
            if eidx in self._used or edge.is_closed:
                continue
            plane = _primary_plane(edge)
            plane_groups.setdefault(plane, []).append(edge)

        # 3. Önce düzlemsel grupları işle (None hariç)
        oblique = plane_groups.pop(None, [])
        for plane, group in sorted(plane_groups.items(),
                                   key=lambda x: (PLANE_PRIORITY.get(
                                       x[0][0] if x[0] else "z", 99),
                                       str(x[0]))):
            results.extend(self._chain_group(group))

        # 4. 3D edge'ler
        if oblique:
            results.extend(self._chain_group(oblique))

        # 5. Orphan
        for edge in self.graph.orphan_edges:
            results.append(PathCandidate(
                segments=[edge], is_closed=False,
                path_kind="orphan", path_id=self._nid(),
            ))

        return results

    # ------------------------------------------------------------------ #

    def _chain_group(self, group: List[BaseEdge]) -> List[PathCandidate]:
        available = {
            e.edge_index: e for e in group
            if e.edge_index not in self._used
        }
        if not available:
            return []

        adj     = self._build_adj(available)
        degrees = {v: len(nb) for v, nb in adj.items()}
        endpoints = [v for v, d in degrees.items() if d == 1]

        chains = []

        # Endpoint'lerden başla
        for sv in endpoints:
            if not any(x["edge_index"] in available
                       for x in adj.get(sv, [])):
                continue
            chain = self._walk(sv, adj, available)
            if chain:
                closed = _is_closed(chain)
                chains.append(PathCandidate(
                    segments=chain, is_closed=closed,
                    path_kind="closed_loop" if closed else "open_chain",
                    path_id=self._nid(),
                ))

        # Kalan → kapalı döngüler
        while available:
            sv = next(
                (v for v in adj
                 if any(x["edge_index"] in available
                        for x in adj.get(v, []))),
                None
            )
            if sv is None:
                break
            chain = self._walk(sv, adj, available)
            if not chain:
                eidx = next(iter(available))
                e = available.pop(eidx)
                self._used.add(eidx)
                chains.append(PathCandidate(
                    segments=[e], is_closed=False,
                    path_kind="open_chain", path_id=self._nid(),
                ))
                continue
            closed = _is_closed(chain)
            chains.append(PathCandidate(
                segments=chain, is_closed=closed,
                path_kind="closed_loop" if closed else "open_chain",
                path_id=self._nid(),
            ))

        return chains

    # ------------------------------------------------------------------ #

    def _walk(self, start: int, adj: Dict, available: Dict) -> List[BaseEdge]:
        chain   = []
        current = start
        while True:
            neighbors = [x for x in adj.get(current, [])
                         if x["edge_index"] in available]
            if not neighbors:
                break
            chosen = neighbors[0]
            eidx   = chosen["edge_index"]
            nv     = chosen["neighbor"]
            edge   = available.pop(eidx)
            self._used.add(eidx)
            adj[current] = [x for x in adj.get(current, [])
                            if x["edge_index"] != eidx]
            adj[nv]      = [x for x in adj.get(nv, [])
                            if x["edge_index"] != eidx]
            chain.append(edge)
            current = nv
            if current == start:
                break
        return chain

    def _build_adj(self, available: Dict) -> Dict:
        from collections import defaultdict
        adj = defaultdict(list)
        for eidx, edge in available.items():
            sv = self.graph.resolver.resolve(
                edge.start_vertex_id, edge.start_point)
            ev = self.graph.resolver.resolve(
                edge.end_vertex_id, edge.end_point)
            if sv is None or ev is None:
                continue
            adj[sv].append({"neighbor": ev, "edge_index": eidx})
            adj[ev].append({"neighbor": sv, "edge_index": eidx})
        return dict(adj)

    def _nid(self) -> int:
        self._counter += 1
        return self._counter


def _is_closed(chain: List[BaseEdge]) -> bool:
    if not chain:
        return False
    sv = chain[0].start_vertex_id
    ev = chain[-1].end_vertex_id
    if sv is not None and ev is not None:
        return sv == ev
    sp = chain[0].start_point
    ep = chain[-1].end_point
    if sp and ep:
        return math.sqrt(sum((a-b)**2 for a, b in zip(sp, ep))) < 1e-4
    return False
