"""
inventor_extractor.py
=====================
Autodesk Inventor'dan açık olan parçanın tüm edge geometrisini çeker
ve geometry_output.json olarak kaydeder.

Gereksinimler:
    pip install pywin32
    Inventor'ın açık ve bir PartDocument aktif olması gerekir.

Kullanım:
    python inventor_extractor.py
    python inventor_extractor.py --output benim_parcam.json
    python inventor_extractor.py --output benim_parcam.json --body 1

Ne üretir:
    geometry_output.json  →  main.py'nin beklediği format
"""

from __future__ import annotations
import json
import math
import argparse
import sys
from pathlib import Path
from typing import Optional, Tuple

# ---------------------------------------------------------------------------
# pywin32 kontrolü
# ---------------------------------------------------------------------------
try:
    from win32com.client import gencache, CastTo
except ImportError:
    print("HATA: pywin32 kurulu değil.")
    print("      Çözüm: pip install pywin32")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Yardımcı dönüştürücüler
# ---------------------------------------------------------------------------

def _pt(pt_obj) -> Tuple[float, float, float]:
    """Inventor Point nesnesi → (x, y, z) tuple"""
    return (round(pt_obj.X, 6), round(pt_obj.Y, 6), round(pt_obj.Z, 6))


def _vec(vec_obj) -> Tuple[float, float, float]:
    """Inventor Vector nesnesi → (x, y, z) tuple"""
    return (round(vec_obj.X, 6), round(vec_obj.Y, 6), round(vec_obj.Z, 6))


def _safe(obj, attr, transform=None, default=None):
    """
    Inventor COM nesnelerinde attr okurken hata fırlayabilir.
    Bu fonksiyon güvenli şekilde okur, hata olursa default döner.
    """
    try:
        value = getattr(obj, attr)
        return transform(value) if transform else value
    except Exception:
        return default


def _dist(p1, p2) -> float:
    return round(math.sqrt(sum((a - b) ** 2 for a, b in zip(p1, p2))), 6)


# ---------------------------------------------------------------------------
# Vertex haritası
# ---------------------------------------------------------------------------

def build_vertex_map(body):
    """
    body.Vertices → { vertex_id: point_tuple } ve { point_sig: vertex_id }

    Neden gerekli:
        Edge'lerin StartVertex / StopVertex nesneleri bazen
        doğrudan integer ID vermez. Koordinat imzası üzerinden
        tutarlı bir ID sistemi kuruyoruz.
    """
    id_to_point = {}
    sig_to_id = {}

    for i in range(1, body.Vertices.Count + 1):
        vertex = body.Vertices.Item(i)
        pt = _pt(vertex.Point)
        sig = pt  # tuple zaten hashable
        id_to_point[i] = pt
        sig_to_id[sig] = i

    return id_to_point, sig_to_id


def resolve_vertex_id(vertex_obj, sig_to_id: dict) -> Optional[int]:
    """Inventor vertex nesnesinden integer vertex_id çöz."""
    if vertex_obj is None:
        return None
    try:
        pt = _pt(vertex_obj.Point)
        return sig_to_id.get(pt)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Edge topoloji bilgisi
# ---------------------------------------------------------------------------

def get_edge_topology(edge, sig_to_id: dict) -> dict:
    """
    Edge'in başlangıç / bitiş vertex_id'lerini ve
    bağlı yüz sayısını döndürür.
    """
    start_vid = None
    end_vid = None
    face_count = None

    try:
        start_vid = resolve_vertex_id(edge.StartVertex, sig_to_id)
    except Exception:
        pass

    try:
        # Inventor API'sinde StopVertex ya da EndVertex kullanılır
        stop = getattr(edge, "StopVertex", None) or getattr(edge, "EndVertex", None)
        end_vid = resolve_vertex_id(stop, sig_to_id)
    except Exception:
        pass

    try:
        face_count = edge.Faces.Count
    except Exception:
        pass

    return {
        "start_vertex_id": start_vid,
        "end_vertex_id":   end_vid,
        "connected_face_count": face_count,
    }


# ---------------------------------------------------------------------------
# Geometri tipi tespiti ve veri çekme
# ---------------------------------------------------------------------------

# Inventor'ın döndürdüğü ham tip adları → bizim tip adlarımız
ARC_TYPES      = {"Arc3d", "CircularArc", "Arc2d", "Arc"}
ELLIPSE_TYPES  = {"Ellipse", "EllipticalArc", "EllipseFull", "EllipticalFull",
                  "EllipseArc"}
SPLINE_TYPES   = {"BSplineCurve", "BSplineCurve2d", "SplineCurve",
                  "NurbsCurve", "BSpline"}


def classify_and_extract(geom, body_index: int, edge_index: int,
                         topology: dict) -> dict:
    """
    Inventor geometry nesnesini analiz edip JSON-uyumlu dict üretir.
    Bilinmeyen tipler 'Unknown' olarak sınıflandırılır.
    """
    raw_type = geom.__class__.__name__
    base = {
        "body_index":  body_index,
        "edge_index":  edge_index,
        "raw_type":    raw_type,
        **topology,
    }

    # ---- LineSegment ----
    if raw_type == "LineSegment":
        start = _safe(geom, "StartPoint", _pt)
        end   = _safe(geom, "EndPoint",   _pt)
        length = _dist(start, end) if start and end else None
        return {**base, "type": "LineSegment",
                "start": start, "end": end, "length": length}

    # ---- Circle ----
    if raw_type == "Circle":
        center = _safe(geom, "Center", _pt)
        radius = _safe(geom, "Radius", lambda x: round(x, 6))
        normal = _safe(geom, "Normal", _vec)
        return {**base, "type": "Circle",
                "center": center, "radius": radius, "normal": normal}

    # ---- Arc ----
    if raw_type in ARC_TYPES:
        return {
            **base, "type": "Arc",
            "center":      _safe(geom, "Center",     _pt),
            "radius":      _safe(geom, "Radius",     lambda x: round(x, 6)),
            "start_point": _safe(geom, "StartPoint", _pt),
            "end_point":   _safe(geom, "EndPoint",   _pt),
            "normal":      _safe(geom, "Normal",     _vec),
            "start_angle": _safe(geom, "StartAngle", lambda x: round(x, 6)),
            "sweep_angle": _safe(geom, "SweepAngle", lambda x: round(x, 6)),
        }

    # ---- Ellipse / EllipticalArc ----
    if raw_type in ELLIPSE_TYPES:
        return {
            **base, "type": "Ellipse",
            "center":       _safe(geom, "Center",          _pt),
            "major_radius": _safe(geom, "MajorRadius",     lambda x: round(x, 6)),
            "minor_radius": _safe(geom, "MinorRadius",     lambda x: round(x, 6)),
            "major_axis":   _safe(geom, "MajorAxisVector", _vec),
            "normal":       _safe(geom, "Normal",          _vec),
            "start_point":  _safe(geom, "StartPoint",      _pt),
            "end_point":    _safe(geom, "EndPoint",        _pt),
            "start_angle":  _safe(geom, "StartAngle",      lambda x: round(x, 6)),
            "sweep_angle":  _safe(geom, "SweepAngle",      lambda x: round(x, 6)),
        }

    # ---- Spline / BSpline / NURBS ----
    if raw_type in SPLINE_TYPES:
        fit_points     = None
        control_points = None

        try:
            fps = geom.FitPoints
            fit_points = [_pt(fps.Item(i)) for i in range(1, fps.Count + 1)]
        except Exception:
            pass

        try:
            cps = geom.ControlPoints
            control_points = [_pt(cps.Item(i)) for i in range(1, cps.Count + 1)]
        except Exception:
            pass

        return {
            **base, "type": "Spline",
            "degree":         _safe(geom, "Degree"),
            "is_closed":      _safe(geom, "IsClosed"),
            "fit_points":     fit_points,
            "control_points": control_points,
        }

    # ---- Bilinmeyen tip ----
    # Mümkün olduğu kadar veri toplamaya çalış
    extra = {}
    for attr in ("Center", "Radius", "StartPoint", "EndPoint",
                 "Normal", "StartAngle", "SweepAngle", "Length"):
        val = _safe(geom, attr)
        if val is not None:
            # Nokta/vektör nesnelerini tuple'a çevir
            if hasattr(val, "X") and hasattr(val, "Y") and hasattr(val, "Z"):
                val = _pt(val)
            extra[attr.lower()] = val

    return {**base, "type": "Unknown", **extra}


# ---------------------------------------------------------------------------
# Body çekme
# ---------------------------------------------------------------------------

def extract_body(body, body_index: int) -> dict:
    """Tek bir SurfaceBody'nin tüm edge ve vertex verisini döndürür."""

    id_to_point, sig_to_id = build_vertex_map(body)

    edges_data = []
    for edge_index in range(1, body.Edges.Count + 1):
        edge = body.Edges.Item(edge_index)

        try:
            geom = edge.Geometry
        except Exception:
            # Geometry alınamayan edge → Unknown olarak kaydet
            topo = get_edge_topology(edge, sig_to_id)
            edges_data.append({
                "body_index": body_index,
                "edge_index": edge_index,
                "raw_type":   "NoGeometry",
                "type":       "Unknown",
                **topo,
            })
            continue

        topology = get_edge_topology(edge, sig_to_id)
        edge_dict = classify_and_extract(geom, body_index, edge_index, topology)
        edges_data.append(edge_dict)

    vertices_data = [
        {"vertex_id": vid, "point": pt}
        for vid, pt in id_to_point.items()
    ]

    return {
        "body_index":   body_index,
        "face_count":   body.Faces.Count,
        "edge_count":   body.Edges.Count,
        "vertex_count": body.Vertices.Count,
        "vertices":     vertices_data,
        "edges":        edges_data,
    }


# ---------------------------------------------------------------------------
# Ana çekici
# ---------------------------------------------------------------------------

class InventorExtractor:

    def __init__(self):
        print("Inventor bağlantısı kuruluyor...")
        try:
            self.inv = gencache.EnsureDispatch("Inventor.Application")
            self.inv.Visible = True
            print(f"Bağlandı: Inventor {self.inv.SoftwareVersion}")
        except Exception as e:
            print(f"HATA: Inventor'a bağlanılamadı: {e}")
            print("      Inventor'ın açık olduğundan emin olun.")
            sys.exit(1)

    def extract(self, target_body_index: Optional[int] = None) -> dict:
        """
        Aktif PartDocument'taki geometriyi çeker.

        target_body_index: None → tüm body'ler, 1 → sadece ilk body
        """
        # Aktif dokümanı al
        try:
            doc = self.inv.ActiveDocument
        except Exception:
            print("HATA: Aktif doküman bulunamadı. Inventor'da bir parça açın.")
            sys.exit(1)

        # PartDocument'a cast et
        try:
            part_doc = CastTo(doc, "PartDocument")
            comp = part_doc.ComponentDefinition
        except Exception:
            print("HATA: Aktif doküman bir PartDocument değil.")
            print("      Assembly değil, parça (.ipt) dosyası açık olmalı.")
            sys.exit(1)

        doc_name   = doc.DisplayName
        body_count = comp.SurfaceBodies.Count

        print(f"Parça: {doc_name}")
        print(f"Body sayısı: {body_count}")

        # Hangi body'leri çekeceğimizi belirle
        if target_body_index is not None:
            if target_body_index < 1 or target_body_index > body_count:
                print(f"HATA: --body {target_body_index} geçersiz "
                      f"(toplam {body_count} body var).")
                sys.exit(1)
            body_indices = [target_body_index]
        else:
            body_indices = list(range(1, body_count + 1))

        # Body'leri çek
        bodies_data = []
        all_edges   = []

        for body_index in body_indices:
            body = comp.SurfaceBodies.Item(body_index)
            print(f"  Body {body_index}: "
                  f"{body.Edges.Count} edge, "
                  f"{body.Faces.Count} yüz, "
                  f"{body.Vertices.Count} vertex")

            body_data = extract_body(body, body_index)
            bodies_data.append(body_data)
            all_edges.extend(body_data["edges"])

        # Geometri tipi özeti
        from collections import Counter
        type_summary = dict(Counter(e["type"]     for e in all_edges))
        raw_summary  = dict(Counter(e["raw_type"] for e in all_edges))

        result = {
            "document_name":  doc_name,
            "body_count":     body_count,
            "extracted_bodies": body_indices,
            "bodies":         bodies_data,
            "all_edges":      all_edges,
            "summary": {
                "total_edges": len(all_edges),
                "by_type":     type_summary,
                "by_raw_type": raw_summary,
            }
        }

        return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Inventor'dan geometri çeker ve JSON olarak kaydeder."
    )
    parser.add_argument(
        "--output", "-o",
        type=str,
        default="geometry_output.json",
        help="Çıktı JSON dosyası (varsayılan: geometry_output.json)",
    )
    parser.add_argument(
        "--body",
        type=int,
        default=None,
        help="Sadece belirli bir body'i çek (ör. --body 1). "
             "Belirtilmezse tüm body'ler çekilir.",
    )
    args = parser.parse_args()

    extractor = InventorExtractor()
    data = extractor.extract(target_body_index=args.body)

    # Kaydet
    output_path = Path(args.output)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    print(f"\nToplam edge: {data['summary']['total_edges']}")
    print("\nGeometri tipi dağılımı:")
    for t, count in data["summary"]["by_type"].items():
        print(f"  {t:15s}: {count}")

    print(f"\nKaydedildi → {output_path.resolve()}")
    print("\nŞimdi patika tespiti için:")
    print(f"  python main.py {output_path}")


if __name__ == "__main__":
    main()
