' ============================================================
' iLogic Rule: Geometri Sayım v3
' TypeOf ile Inventor interface kontrolü yapılır
' ============================================================

Dim oDoc As PartDocument = ThisDoc.Document
Dim oComp As PartComponentDefinition = oDoc.ComponentDefinition
Dim oBodies As SurfaceBodies = oComp.SurfaceBodies
Dim bodyCount As Integer = oBodies.Count

' --- Sayaçlar ---
Dim totalVertex  As Integer = 0
Dim totalEdge    As Integer = 0
Dim totalFace    As Integer = 0

Dim cntLine      As Integer = 0
Dim cntCircle    As Integer = 0
Dim cntArc       As Integer = 0
Dim cntEllipse   As Integer = 0
Dim cntEllipArc  As Integer = 0
Dim cntSpline    As Integer = 0
Dim cntOtherEdge As Integer = 0

Dim cntPlane     As Integer = 0
Dim cntCylinder  As Integer = 0
Dim cntCone      As Integer = 0
Dim cntSphere    As Integer = 0
Dim cntTorus     As Integer = 0
Dim cntSplineSrf As Integer = 0
Dim cntOtherFace As Integer = 0

' ============================================================
For b As Integer = 1 To bodyCount
    Dim oBody As SurfaceBody = oBodies.Item(b)

    totalVertex += oBody.Vertices.Count
    totalEdge   += oBody.Edges.Count
    totalFace   += oBody.Faces.Count

    ' --- EDGE TİPİ ---
    For e As Integer = 1 To oBody.Edges.Count
        Dim oEdge As Edge = oBody.Edges.Item(e)
        Dim g As Object = oEdge.Geometry

        If TypeOf g Is LineSegment Then
            cntLine += 1
        ElseIf TypeOf g Is Circle Then
            cntCircle += 1
        ElseIf TypeOf g Is Arc3d Then
            cntArc += 1
        ElseIf TypeOf g Is EllipseFull Then
            cntEllipse += 1
        ElseIf TypeOf g Is EllipticalArc Then
            cntEllipArc += 1
        ElseIf TypeOf g Is BSplineCurve Then
            cntSpline += 1
        Else
            cntOtherEdge += 1
        End If
    Next

    ' --- FACE TİPİ ---
    For f As Integer = 1 To oBody.Faces.Count
        Dim oFace As Face = oBody.Faces.Item(f)
        Dim s As Object = oFace.Geometry

        If TypeOf s Is Plane Then
            cntPlane += 1
        ElseIf TypeOf s Is Cylinder Then
            cntCylinder += 1
        ElseIf TypeOf s Is Cone Then
            cntCone += 1
        ElseIf TypeOf s Is Sphere Then
            cntSphere += 1
        ElseIf TypeOf s Is Torus Then
            cntTorus += 1
        ElseIf TypeOf s Is BSplineSurface Then
            cntSplineSrf += 1
        Else
            cntOtherFace += 1
        End If
    Next

Next b

' ============================================================
' MESAJ
' ============================================================
Dim nl  As String = vbCrLf
Dim sep As String = New String("-"c, 36)

Dim msg As String = ""
msg &= "GEOMETRİ SAYIM RAPORU" & nl
msg &= sep & nl
msg &= "Dosya : " & oDoc.DisplayName & nl
msg &= "Body  : " & bodyCount & nl
msg &= sep & nl

msg &= "GENEL TOPLAM" & nl
msg &= "  Vertex : " & totalVertex & nl
msg &= "  Edge   : " & totalEdge   & nl
msg &= "  Face   : " & totalFace   & nl
msg &= sep & nl

msg &= "EDGE TİPLERİ" & nl
msg &= "  LineSegment   : " & cntLine      & nl
msg &= "  Circle        : " & cntCircle    & nl
msg &= "  Arc           : " & cntArc       & nl
msg &= "  Ellipse       : " & cntEllipse   & nl
msg &= "  EllipticalArc : " & cntEllipArc  & nl
msg &= "  Spline        : " & cntSpline    & nl
msg &= "  Diğer         : " & cntOtherEdge & nl
msg &= sep & nl

msg &= "FACE TİPLERİ" & nl
msg &= "  Plane    : " & cntPlane     & nl
msg &= "  Cylinder : " & cntCylinder  & nl
msg &= "  Cone     : " & cntCone      & nl
msg &= "  Sphere   : " & cntSphere    & nl
msg &= "  Torus    : " & cntTorus     & nl
msg &= "  BSpline  : " & cntSplineSrf & nl
msg &= "  Diğer    : " & cntOtherFace & nl
msg &= sep & nl

msg &= "PYTHON KARŞILAŞTIRMA:" & nl
msg &= "  summary.by_type = {" & nl
If cntLine      > 0 Then msg &= "    LineSegment: " & cntLine      & nl
If cntCircle    > 0 Then msg &= "    Circle:      " & cntCircle    & nl
If cntArc       > 0 Then msg &= "    Arc:         " & cntArc       & nl
If cntEllipse   > 0 Then msg &= "    Ellipse:     " & cntEllipse   & nl
If cntEllipArc  > 0 Then msg &= "    EllipseArc:  " & cntEllipArc  & nl
If cntSpline    > 0 Then msg &= "    Spline:      " & cntSpline    & nl
If cntOtherEdge > 0 Then msg &= "    Unknown:     " & cntOtherEdge & nl
msg &= "  }" & nl
msg &= sep

MsgBox(msg, MsgBoxStyle.Information, "iLogic — Geometri Sayım v3")
