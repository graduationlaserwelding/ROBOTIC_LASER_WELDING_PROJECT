"""
path_classifier.py
==================
PathCandidate listesini analiz eder ve her path'e ek bilgi ekler.

Ne yapar:
    1. Düzlem tespiti  (hangi koordinat düzleminde, yoksa "free")
    2. Normal vektörü tahmini (düzlemsel path için)
    3. Kaynak dikiş skoru  (kapalı + tek düzlem + makul uzunluk → yüksek skor)
    4. Filtreleme yardımcıları

Skor mantığı (0–100):
    +40  Kapalı loop (closed_loop veya isolated_closed)
    +20  Tek ve net bir düzlemde yatıyor
    +20  Arc veya Circle içeriyor (kaynak dikiş için tipik)
    +10  Bağlı yüz sayısı == 2 olan edge'leri var (parça birleşim yüzeyi)
    +10  Uzunluk makul aralıkta (çok kısa / çok uzun değil)
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict

from geometry_models import BaseEdge, ArcEdge, CircleEdge
from path_finder import PathCandidate

Vector3D = Tuple[float, float, float]

AXIS_TOL = 1e-4   # normal vektörünün eksenle ne kadar hizalı sayılacağı


# ---------------------------------------------------------------------------
# Düzlem tespiti
# ---------------------------------------------------------------------------

def detect_plane(candidate: PathCandidate) -> Tuple[Optional[str], Optional[float]]:
    """
    Path'in hangi koordinat düzleminde yattığını tespit eder.

    Dönüş: ("x"|"y"|"z"|"free"|"unknown", düzlem değeri ya da None)

    Yöntem:
        - Eğer path Arc/Circle içeriyorsa → normal vektörüne bak
        - Değilse → tüm uç noktaların koordinatlarını karşılaştır
    """
    segs = candidate.segments

    # 1. Normal vektörü olan segment varsa önce ona bak
    normals = []
    for seg in segs:
        n = getattr(seg, "normal", None)
        if n is not None:
            normals.append(n)

    if normals:
        plane_axis, plane_val = _plane_from_normals(normals, segs)
        if plane_axis != "unknown":
            return plane_axis, plane_val

    # 2. Tüm uç noktaların koordinatlarına bak
    points = _collect_points(segs)
    if not points:
        return "unknown", None

    return _plane_from_points(points)


def _plane_from_normals(normals, segs) -> Tuple[str, Optional[float]]:
    """Normal vektörlerinin ortalamasını alarak düzlemi bul."""
    avg = [sum(n[i] for n in normals) / len(normals) for i in range(3)]
    length = math.sqrt(sum(x**2 for x in avg))
    if length < 1e-9:
        return "unknown", None
    avg = [x / length for x in avg]

    axes = [("x", 0), ("y", 1), ("z", 2)]
    for axis, idx in axes:
        if abs(abs(avg[idx]) - 1.0) < AXIS_TOL:
            # Normal bu eksene paralel → path bu eksene dik düzlemde
            # Düzlem değerini center/point'ten al
            centers = [getattr(s, "center", None) for s in segs]
            centers = [c for c in centers if c is not None]
            if centers:
                val = round(centers[0][idx], 6)
                return axis, val
            return axis, None

    return "unknown", None


def _collect_points(segs):
    pts = []
    for seg in segs:
        sp = seg.start_point
        ep = seg.end_point
        if sp:
            pts.append(sp)
        if ep:
            pts.append(ep)
        # Arc / Circle için center'ı da ekle
        c = getattr(seg, "center", None)
        if c:
            pts.append(c)
    return pts


def _plane_from_points(points) -> Tuple[str, Optional[float]]:
    """Tüm noktalar aynı koordinat düzleminde mi?"""
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    zs = [p[2] for p in points]

    tol = 1e-4
    if max(xs) - min(xs) < tol:
        return "x", round(xs[0], 6)
    if max(ys) - min(ys) < tol:
        return "y", round(ys[0], 6)
    if max(zs) - min(zs) < tol:
        return "z", round(zs[0], 6)

    return "free", None


# ---------------------------------------------------------------------------
# Skor hesaplama
# ---------------------------------------------------------------------------

def score_candidate(candidate: PathCandidate,
                    plane_axis: Optional[str],
                    all_lengths: List[float]) -> int:
    score = 0

    # +40: Kapalı
    if candidate.is_closed:
        score += 40

    # +20: Net bir düzlemde
    if plane_axis in ("x", "y", "z"):
        score += 20

    # +20: Arc veya Circle içeriyor
    has_curve = any(isinstance(s, (ArcEdge, CircleEdge))
                    for s in candidate.segments)
    if has_curve:
        score += 20

    # +10: Birleşim yüzeyi edge'i var (connected_face_count == 2)
    has_junction = any(
        s.connected_face_count == 2 for s in candidate.segments
    )
    if has_junction:
        score += 10

    # +10: Uzunluk makul — medyan uzunluğa çok yakın değil, çok uzak da değil
    if all_lengths and candidate.total_length > 0:
        median = sorted(all_lengths)[len(all_lengths) // 2]
        ratio = candidate.total_length / (median + 1e-9)
        if 0.1 <= ratio <= 10.0:
            score += 10

    return min(score, 100)


# ---------------------------------------------------------------------------
# AnnotatedPath — classifier çıktısı
# ---------------------------------------------------------------------------

@dataclass
class AnnotatedPath:
    candidate:   PathCandidate
    plane_axis:  Optional[str]    = None   # "x"|"y"|"z"|"free"|"unknown"
    plane_value: Optional[float]  = None
    score:       int              = 0
    notes:       List[str]        = field(default_factory=list)

    # --- Kısayollar --- #
    @property
    def path_id(self):     return self.candidate.path_id
    @property
    def path_kind(self):   return self.candidate.path_kind
    @property
    def is_closed(self):   return self.candidate.is_closed
    @property
    def segment_count(self): return self.candidate.segment_count
    @property
    def total_length(self):  return self.candidate.total_length
    @property
    def geom_types(self):    return self.candidate.geom_types

    def to_dict(self) -> dict:
        d = self.candidate.to_dict()
        d.update({
            "plane_axis":  self.plane_axis,
            "plane_value": self.plane_value,
            "score":       self.score,
            "notes":       self.notes,
        })
        return d

    def __repr__(self):
        plane_str = (f"{self.plane_axis}={self.plane_value}"
                     if self.plane_value is not None else self.plane_axis)
        return (f"AnnotatedPath(id={self.path_id}, score={self.score}, "
                f"kind={self.path_kind}, closed={self.is_closed}, "
                f"plane={plane_str}, types={self.geom_types})")


# ---------------------------------------------------------------------------
# Classifier — ana fonksiyon
# ---------------------------------------------------------------------------

def classify_candidates(candidates: List[PathCandidate]) -> List[AnnotatedPath]:
    """
    Tüm PathCandidate'leri analiz et, AnnotatedPath listesi döndür.
    Skor'a göre azalan sırayla sıralar.
    """
    all_lengths = [c.total_length for c in candidates if c.total_length > 0]

    annotated = []
    for cand in candidates:
        plane_axis, plane_val = detect_plane(cand)
        score = score_candidate(cand, plane_axis, all_lengths)

        notes = []
        if cand.path_kind == "orphan":
            notes.append("vertex bağlantısı kurulamadı")
        if plane_axis == "free":
            notes.append("düzlemsel değil — 3D path")
        if plane_axis == "unknown":
            notes.append("düzlem tespit edilemedi")
        if cand.segment_count == 1 and not cand.is_closed:
            notes.append("tek segment, açık uçlu")

        ap = AnnotatedPath(
            candidate=cand,
            plane_axis=plane_axis,
            plane_value=plane_val,
            score=score,
            notes=notes,
        )
        annotated.append(ap)

    # Skora göre sırala
    annotated.sort(key=lambda a: a.score, reverse=True)
    return annotated


# ---------------------------------------------------------------------------
# Filtreleme yardımcıları
# ---------------------------------------------------------------------------

def filter_by_min_score(paths: List[AnnotatedPath],
                         min_score: int) -> List[AnnotatedPath]:
    return [p for p in paths if p.score >= min_score]


def filter_closed_only(paths: List[AnnotatedPath]) -> List[AnnotatedPath]:
    return [p for p in paths if p.is_closed]


def filter_by_plane(paths: List[AnnotatedPath],
                    axis: str,
                    value: Optional[float] = None,
                    tol: float = 1e-4) -> List[AnnotatedPath]:
    result = [p for p in paths if p.plane_axis == axis]
    if value is not None:
        result = [p for p in result
                  if p.plane_value is not None
                  and abs(p.plane_value - value) <= tol]
    return result
