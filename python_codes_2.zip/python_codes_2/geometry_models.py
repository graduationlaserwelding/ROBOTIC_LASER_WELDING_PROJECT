"""
geometry_models.py
==================
Inventor'dan çekilen edge verilerini temsil eden veri sınıfları.

Desteklenen tipler:
    - LineSegment
    - Arc
    - Circle
    - Ellipse
    - Spline
    - Unknown  (tanımlanamayan her şey buraya düşer)

Her sınıf:
    - from_dict(d)  → JSON / dict'ten nesne üret
    - to_dict()     → JSON'a geri dönüştür
    - start_point / end_point property'leri  (zincir kurucunun kullanacağı)
    - is_closed property  (Circle gibi tipler için True)
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Optional, Tuple, List


Point3D = Tuple[float, float, float]
Vector3D = Tuple[float, float, float]


# ---------------------------------------------------------------------------
# Yardımcı fonksiyonlar
# ---------------------------------------------------------------------------

def _pt(raw) -> Optional[Point3D]:
    """Liste / None → tuple ya da None."""
    if raw is None:
        return None
    return (float(raw[0]), float(raw[1]), float(raw[2]))


def _vec(raw) -> Optional[Vector3D]:
    return _pt(raw)


def _r(v, n=6) -> Optional[float]:
    return round(float(v), n) if v is not None else None


# ---------------------------------------------------------------------------
# Taban sınıf
# ---------------------------------------------------------------------------

@dataclass
class BaseEdge:
    body_index: int
    edge_index: int
    raw_type: str
    geom_type: str                          # "LineSegment", "Arc", ...
    start_vertex_id: Optional[int] = None
    end_vertex_id:   Optional[int] = None
    connected_face_count: Optional[int] = None

    # ---- Zincir kurucunun ihtiyaç duyduğu arayüz ----

    @property
    def start_point(self) -> Optional[Point3D]:
        """Segmentin başlangıç noktası (override edilmeli)."""
        return None

    @property
    def end_point(self) -> Optional[Point3D]:
        """Segmentin bitiş noktası (override edilmeli)."""
        return None

    @property
    def is_closed(self) -> bool:
        """Kendi başına kapalı mı? (Circle, tam Ellipse, kapalı Spline)."""
        return False

    @property
    def has_topology(self) -> bool:
        """Vertex ID bilgisi var mı?"""
        return (self.start_vertex_id is not None
                and self.end_vertex_id is not None)

    # ---- Serializasyon ----

    def _base_dict(self) -> dict:
        return {
            "body_index":           self.body_index,
            "edge_index":           self.edge_index,
            "raw_type":             self.raw_type,
            "type":                 self.geom_type,
            "start_vertex_id":      self.start_vertex_id,
            "end_vertex_id":        self.end_vertex_id,
            "connected_face_count": self.connected_face_count,
        }

    def to_dict(self) -> dict:
        return self._base_dict()

    @classmethod
    def from_dict(cls, d: dict) -> "BaseEdge":
        raise NotImplementedError


# ---------------------------------------------------------------------------
# LineSegment
# ---------------------------------------------------------------------------

@dataclass
class LineSegmentEdge(BaseEdge):
    p_start: Optional[Point3D] = None
    p_end:   Optional[Point3D] = None
    length:  Optional[float]   = None

    def __post_init__(self):
        self.geom_type = "LineSegment"

    @property
    def start_point(self): return self.p_start

    @property
    def end_point(self): return self.p_end

    def to_dict(self) -> dict:
        d = self._base_dict()
        d.update({"start": self.p_start, "end": self.p_end, "length": self.length})
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "LineSegmentEdge":
        return cls(
            body_index=d["body_index"],
            edge_index=d["edge_index"],
            raw_type=d["raw_type"],
            geom_type="LineSegment",
            start_vertex_id=d.get("start_vertex_id"),
            end_vertex_id=d.get("end_vertex_id"),
            connected_face_count=d.get("connected_face_count"),
            p_start=_pt(d.get("start")),
            p_end=_pt(d.get("end")),
            length=_r(d.get("length")),
        )


# ---------------------------------------------------------------------------
# Arc
# ---------------------------------------------------------------------------

@dataclass
class ArcEdge(BaseEdge):
    center:      Optional[Point3D]  = None
    radius:      Optional[float]    = None
    p_start:     Optional[Point3D]  = None
    p_end:       Optional[Point3D]  = None
    normal:      Optional[Vector3D] = None
    start_angle: Optional[float]    = None
    sweep_angle: Optional[float]    = None

    def __post_init__(self):
        self.geom_type = "Arc"

    @property
    def start_point(self): return self.p_start

    @property
    def end_point(self): return self.p_end

    @property
    def arc_length(self) -> Optional[float]:
        if self.radius is not None and self.sweep_angle is not None:
            return abs(self.radius * self.sweep_angle)
        return None

    def to_dict(self) -> dict:
        d = self._base_dict()
        d.update({
            "center": self.center, "radius": self.radius,
            "start_point": self.p_start, "end_point": self.p_end,
            "normal": self.normal,
            "start_angle": self.start_angle, "sweep_angle": self.sweep_angle,
        })
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "ArcEdge":
        return cls(
            body_index=d["body_index"], edge_index=d["edge_index"],
            raw_type=d["raw_type"], geom_type="Arc",
            start_vertex_id=d.get("start_vertex_id"),
            end_vertex_id=d.get("end_vertex_id"),
            connected_face_count=d.get("connected_face_count"),
            center=_pt(d.get("center")), radius=_r(d.get("radius")),
            p_start=_pt(d.get("start_point")), p_end=_pt(d.get("end_point")),
            normal=_vec(d.get("normal")),
            start_angle=_r(d.get("start_angle")),
            sweep_angle=_r(d.get("sweep_angle")),
        )


# ---------------------------------------------------------------------------
# Circle  (kendi başına kapalı)
# ---------------------------------------------------------------------------

@dataclass
class CircleEdge(BaseEdge):
    center: Optional[Point3D]  = None
    radius: Optional[float]    = None
    normal: Optional[Vector3D] = None

    def __post_init__(self):
        self.geom_type = "Circle"

    @property
    def is_closed(self): return True

    @property
    def circumference(self) -> Optional[float]:
        if self.radius is not None:
            return round(2 * math.pi * self.radius, 6)
        return None

    # Circle'ın start/end noktası yok — zincir kurucusu bunu is_closed ile yönetir
    @property
    def start_point(self): return self.center  # referans nokta

    @property
    def end_point(self): return self.center

    def to_dict(self) -> dict:
        d = self._base_dict()
        d.update({"center": self.center, "radius": self.radius, "normal": self.normal})
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "CircleEdge":
        return cls(
            body_index=d["body_index"], edge_index=d["edge_index"],
            raw_type=d["raw_type"], geom_type="Circle",
            start_vertex_id=d.get("start_vertex_id"),
            end_vertex_id=d.get("end_vertex_id"),
            connected_face_count=d.get("connected_face_count"),
            center=_pt(d.get("center")), radius=_r(d.get("radius")),
            normal=_vec(d.get("normal")),
        )


# ---------------------------------------------------------------------------
# Ellipse / EllipticalArc
# ---------------------------------------------------------------------------

@dataclass
class EllipseEdge(BaseEdge):
    center:       Optional[Point3D]  = None
    major_radius: Optional[float]    = None
    minor_radius: Optional[float]    = None
    major_axis:   Optional[Vector3D] = None
    normal:       Optional[Vector3D] = None
    # Tam elips mi yoksa yay mı?
    p_start:      Optional[Point3D]  = None
    p_end:        Optional[Point3D]  = None
    start_angle:  Optional[float]    = None
    sweep_angle:  Optional[float]    = None

    def __post_init__(self):
        self.geom_type = "Ellipse"

    @property
    def is_closed(self):
        # Tam elips → sweep_angle yok ya da 2π
        if self.sweep_angle is None:
            return True
        return abs(self.sweep_angle - 2 * math.pi) < 1e-4

    @property
    def start_point(self): return self.p_start if self.p_start else self.center

    @property
    def end_point(self): return self.p_end if self.p_end else self.center

    def to_dict(self) -> dict:
        d = self._base_dict()
        d.update({
            "center": self.center, "major_radius": self.major_radius,
            "minor_radius": self.minor_radius, "major_axis": self.major_axis,
            "normal": self.normal, "start_point": self.p_start,
            "end_point": self.p_end, "start_angle": self.start_angle,
            "sweep_angle": self.sweep_angle,
        })
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "EllipseEdge":
        return cls(
            body_index=d["body_index"], edge_index=d["edge_index"],
            raw_type=d["raw_type"], geom_type="Ellipse",
            start_vertex_id=d.get("start_vertex_id"),
            end_vertex_id=d.get("end_vertex_id"),
            connected_face_count=d.get("connected_face_count"),
            center=_pt(d.get("center")),
            major_radius=_r(d.get("major_radius")),
            minor_radius=_r(d.get("minor_radius")),
            major_axis=_vec(d.get("major_axis")),
            normal=_vec(d.get("normal")),
            p_start=_pt(d.get("start_point")),
            p_end=_pt(d.get("end_point")),
            start_angle=_r(d.get("start_angle")),
            sweep_angle=_r(d.get("sweep_angle")),
        )


# ---------------------------------------------------------------------------
# Spline / BSpline / NURBS
# ---------------------------------------------------------------------------

@dataclass
class SplineEdge(BaseEdge):
    degree:         Optional[int]        = None
    is_closed_flag: Optional[bool]       = None
    fit_points:     Optional[List[Point3D]] = None
    control_points: Optional[List[Point3D]] = None

    def __post_init__(self):
        self.geom_type = "Spline"

    @property
    def is_closed(self):
        return bool(self.is_closed_flag)

    @property
    def start_point(self):
        if self.fit_points:
            return self.fit_points[0]
        if self.control_points:
            return self.control_points[0]
        return None

    @property
    def end_point(self):
        if self.is_closed:
            return self.start_point
        if self.fit_points:
            return self.fit_points[-1]
        if self.control_points:
            return self.control_points[-1]
        return None

    def to_dict(self) -> dict:
        d = self._base_dict()
        d.update({
            "degree": self.degree, "is_closed": self.is_closed_flag,
            "fit_points": self.fit_points, "control_points": self.control_points,
        })
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "SplineEdge":
        fps = d.get("fit_points")
        cps = d.get("control_points")
        return cls(
            body_index=d["body_index"], edge_index=d["edge_index"],
            raw_type=d["raw_type"], geom_type="Spline",
            start_vertex_id=d.get("start_vertex_id"),
            end_vertex_id=d.get("end_vertex_id"),
            connected_face_count=d.get("connected_face_count"),
            degree=d.get("degree"),
            is_closed_flag=d.get("is_closed"),
            fit_points=[_pt(p) for p in fps] if fps else None,
            control_points=[_pt(p) for p in cps] if cps else None,
        )


# ---------------------------------------------------------------------------
# Unknown  (Inventor'dan gelen tanımlanamayan her tip)
# ---------------------------------------------------------------------------

@dataclass
class UnknownEdge(BaseEdge):
    extra_data: dict = field(default_factory=dict)

    def __post_init__(self):
        self.geom_type = "Unknown"

    def to_dict(self) -> dict:
        d = self._base_dict()
        d.update(self.extra_data)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "UnknownEdge":
        known_keys = {"body_index", "edge_index", "raw_type", "type",
                      "start_vertex_id", "end_vertex_id", "connected_face_count"}
        extra = {k: v for k, v in d.items() if k not in known_keys}
        return cls(
            body_index=d["body_index"], edge_index=d["edge_index"],
            raw_type=d.get("raw_type", "Unknown"), geom_type="Unknown",
            start_vertex_id=d.get("start_vertex_id"),
            end_vertex_id=d.get("end_vertex_id"),
            connected_face_count=d.get("connected_face_count"),
            extra_data=extra,
        )


# ---------------------------------------------------------------------------
# Factory  — JSON dict → doğru sınıf
# ---------------------------------------------------------------------------

_TYPE_MAP = {
    "LineSegment": LineSegmentEdge,
    "Arc":         ArcEdge,
    "Circle":      CircleEdge,
    "Ellipse":     EllipseEdge,
    "Spline":      SplineEdge,
}

def edge_from_dict(d: dict) -> BaseEdge:
    """
    JSON'daki 'type' alanına bakarak doğru Edge nesnesini döndürür.
    Tanımlanamayan tipler UnknownEdge olarak sınıflandırılır.
    """
    geom_type = d.get("type", "Unknown")
    cls = _TYPE_MAP.get(geom_type, UnknownEdge)
    return cls.from_dict(d)


def load_edges_from_geometry_json(geometry_data: dict) -> List[BaseEdge]:
    """
    geometry_output_X.json içindeki all_edges listesini
    BaseEdge nesnelerine dönüştürür.
    """
    return [edge_from_dict(e) for e in geometry_data.get("all_edges", [])]
