' ============================================================
' iLogic Rule: Geometri Sayım ve Doğrulama (v2)
' COM nesne tipi tespiti için CurveType / SurfaceType enum kullanılır
' ============================================================

Dim oDoc As PartDocument
Dim oComp As PartComponentDefinition
Dim oBodies As SurfaceBodies

Try
    oDoc  = ThisDoc.Document
    oComp = oDoc.ComponentDefinition
    oBodies = oComp.SurfaceBodies
Catch ex As Exception
    MsgBox("HATA: Aktif doküman bir PartDocument değil.", , "iLogic Geometri Sayım")
    Return
End Try

' ============================================================
' SAYAÇLAR
' ============================================================
Dim totalEdges    As Integer = 0
Dim totalFaces    As Integer = 0
Dim totalVertices As Integer = 0

' Edge tipleri — Inventor CurveTypeEnum
Dim cntLine       As Integer = 0   ' kLineCurve       = 67109 (LineSegment)
Dim cntCircle     As Integer = 0   ' kCircleCurve     = 67110
Dim cntArc        As Integer = 0   ' kCircularArcCurve= 67111
Dim cntEllipse    As Integer = 0   ' kEllipseCurve    = 67112
Dim cntEllipArc   As Integer = 0   ' kEllipticalArcCurve= 67113
Dim cntSpline     As Integer = 0   ' kBSplineCurve    = 67114
Dim cntOtherEdge  As Integer = 0
Dim otherEdgeNums As New System.Collections.Generic.List(Of String)

' Face tipleri — Inventor SurfaceTypeEnum
Dim cntPlane      As Integer = 0   ' kPlaneSurface    = 67079
Dim cntCyl        As Integer = 0   ' kCylinderSurface = 67080
Dim cntCone       As Integer = 0   ' kConeSurface     = 67081
Dim cntSphere     As Integer = 0   ' kSphereSurface   = 67082
Dim cntTorus      As Integer = 0   ' kTorusSurface    = 67083
Dim cntSplineSurf As Integer = 0   ' kBSplineSurface  = 67084
Dim cntOtherFace  As Integer = 0
Dim otherFaceNums As New System.Collections.Generic.List(Of String)

' ============================================================
' Inventor CurveTypeEnum sabitleri
' (Inventor Type Library'den)
' ============================================================
Const kLineCurve         As Integer = 67109
Const kCircleCurve       As Integer = 67110
Const kCircularArcCurve  As Integer = 67111
Const kEllipseCurve      As Integer = 67112
Const kEllipticalArcCurve As Integer = 67113
Const kBSplineCurve      As Integer = 67114

' Inventor SurfaceTypeEnum sabitleri
Const kPlaneSurface      As Integer = 67079
Const kCylinderSurface   As Integer = 67080
Const kConeSurface       As Integer = 67081
Const kSphereSurface     As Integer = 67082
Const kTorusSurface      As Integer = 67083
Const kBSplineSurface    As Integer = 67084

' ============================================================
' BODY DÖNGÜSÜ
' ============================================================
Dim bodyCount As Integer = oBodies.Count

For bodyIdx As Integer = 1 To bodyCount
    Dim oBody As SurfaceBody = oBodies.Item(bodyIdx)

    totalVertices += oBody.Vertices.Count

    ' --- EDGE ---
    totalEdges += oBody.Edges.Count

    For edgeIdx As Integer = 1 To oBody.Edges.Count
        Dim oEdge As Edge = oBody.Edges.Item(edgeIdx)
        Dim curveType As Integer = 0

        Try
            curveType = oEdge.CurveType
        Catch
            cntOtherEdge += 1
            Continue For
        End Try

        Select Case curveType
            Case kLineCurve
                cntLine += 1
            Case kCircleCurve
                cntCircle += 1
            Case kCircularArcCurve
                cntArc += 1
            Case kEllipseCurve
                cntEllipse += 1
            Case kEllipticalArcCurve
                cntEllipArc += 1
            Case kBSplineCurve
                cntSpline += 1
            Case Else
                cntOtherEdge += 1
                Dim typeStr As String = curveType.ToString()
                If Not otherEdgeNums.Contains(typeStr) Then
                    otherEdgeNums.Add(typeStr)
                End If
        End Select
    Next

    ' --- FACE ---
    totalFaces += oBody.Faces.Count

    For faceIdx As Integer = 1 To oBody.Faces.Count
        Dim oFace As Face = oBody.Faces.Item(faceIdx)
        Dim surfType As Integer = 0

        Try
            surfType = oFace.SurfaceType
        Catch
            cntOtherFace += 1
            Continue For
        End Try

        Select Case surfType
            Case kPlaneSurface
                cntPlane += 1
            Case kCylinderSurface
                cntCyl += 1
            Case kConeSurface
                cntCone += 1
            Case kSphereSurface
                cntSphere += 1
            Case kTorusSurface
                cntTorus += 1
            Case kBSplineSurface
                cntSplineSurf += 1
            Case Else
                cntOtherFace += 1
                Dim typeStr As String = surfType.ToString()
                If Not otherFaceNums.Contains(typeStr) Then
                    otherFaceNums.Add(typeStr)
                End If
        End Select
    Next

Next bodyIdx

' ============================================================
' MESAJ
' ============================================================
Dim nl  As String = vbCrLf
Dim sep As String = New String("-"c, 36)

Dim msg As String = ""
msg &= "INVENTOR GEOMETRİ SAYIM RAPORU" & nl
msg &= sep & nl
msg &= "Dosya : " & oDoc.DisplayName & nl
msg &= "Body  : " & bodyCount & nl
msg &= sep & nl

msg &= "GENEL TOPLAM" & nl
msg &= "  Vertex : " & totalVertices & nl
msg &= "  Edge   : " & totalEdges & nl
msg &= "  Face   : " & totalFaces & nl
msg &= sep & nl

msg &= "EDGE TİPLERİ (CurveType enum)" & nl
msg &= "  LineSegment    : " & cntLine & nl
msg &= "  Circle         : " & cntCircle & nl
msg &= "  Arc            : " & cntArc & nl
msg &= "  Ellipse        : " & cntEllipse & nl
msg &= "  EllipticalArc  : " & cntEllipArc & nl
msg &= "  Spline/BSpline : " & cntSpline & nl
If cntOtherEdge > 0 Then
    msg &= "  Diğer          : " & cntOtherEdge
    If otherEdgeNums.Count > 0 Then
        msg &= " (enum=" & String.Join(",", otherEdgeNums) & ")"
    End If
    msg &= nl
End If
msg &= sep & nl

msg &= "FACE TİPLERİ (SurfaceType enum)" & nl
msg &= "  Plane    : " & cntPlane & nl
msg &= "  Cylinder : " & cntCyl & nl
msg &= "  Cone     : " & cntCone & nl
msg &= "  Sphere   : " & cntSphere & nl
msg &= "  Torus    : " & cntTorus & nl
msg &= "  BSpline  : " & cntSplineSurf & nl
If cntOtherFace > 0 Then
    msg &= "  Diğer    : " & cntOtherFace
    If otherFaceNums.Count > 0 Then
        msg &= " (enum=" & String.Join(",", otherFaceNums) & ")"
    End If
    msg &= nl
End If
msg &= sep & nl

msg &= "PYTHON KODU İLE KARŞILAŞTIR:" & nl
msg &= "  summary.by_type beklenen = {" & nl
If cntLine     > 0 Then msg &= "    'LineSegment': " & cntLine     & nl
If cntCircle   > 0 Then msg &= "    'Circle':      " & cntCircle   & nl
If cntArc      > 0 Then msg &= "    'Arc':         " & cntArc      & nl
If cntEllipse  > 0 Then msg &= "    'Ellipse':     " & cntEllipse  & nl
If cntEllipArc > 0 Then msg &= "    'EllipseArc':  " & cntEllipArc & nl
If cntSpline   > 0 Then msg &= "    'Spline':      " & cntSpline   & nl
If cntOtherEdge> 0 Then msg &= "    'Unknown':     " & cntOtherEdge & nl
msg &= "  }" & nl
msg &= sep

MsgBox(msg, MsgBoxStyle.Information, "iLogic — Geometri Sayım v2")
