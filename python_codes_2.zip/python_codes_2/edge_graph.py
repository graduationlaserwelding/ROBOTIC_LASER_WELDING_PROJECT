"""
edge_graph.py
=============
Tüm edge tiplerini kapsayan graph yapısı.

Ne yapar:
    - Vertex → Edge bağlantılarını tutar (adjacency graph)
    - Connected component tespiti
    - Kapalı edge'leri (Circle, tam Ellipse, kapalı Spline) ayrı tutar
    - Vertex ID eksik edge'ler için nokta koordinatı tabanlı fallback

Kullanım:
    graph = EdgeGraph.from_edges(edges)
    graph.components       → bağlı vertex grupları
    graph.isolated_closed  → Circle gibi tek başına kapalı edge'ler
    graph.orphan_edges     → vertex ID'si olmayan, noktayla da bağlanamayan edge'ler
"""

from __future__ import annotations
import math
from collections import defaultdict, deque
from typing import Dict, List, Optional, Set, Tuple

from geometry_models import (
    BaseEdge, CircleEdge, EllipseEdge, SplineEdge
)

Point3D = Tuple[float, float, float]

# ---------------------------------------------------------------------------
# Tolerans
# ---------------------------------------------------------------------------
POINT_TOL = 1e-5   # iki nokta bu mesafeden yakınsa aynı vertex sayılır


def _dist(a: Point3D, b: Point3D) -> float:
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


# ---------------------------------------------------------------------------
# Vertex → canonical ID çözücü
# Hem Inventor'ın verdiği vertex_id hem de koordinat tabanlı fallback'i yönetir.
# ---------------------------------------------------------------------------

class VertexResolver:
    """
    İki kaynak kullanır:
        1. Inventor'ın atadığı vertex_id  (varsa, tercih edilir)
        2. Nokta koordinatı  (vertex_id yoksa, tolerans tabanlı eşleştirme)

    Her iki kaynaktan da tutarlı bir integer ID üretir.
    """

    def __init__(self):
        self._coord_to_id: Dict[Point3D, int] = {}
        self._next_id = 100_000   # Inventor ID'leriyle çakışmasın

    def resolve(self,
                vertex_id: Optional[int],
                point: Optional[Point3D]) -> Optional[int]:
        """
        vertex_id varsa doğrudan döndür.
        Yoksa point'i kullanarak mevcut koordinatlarla eşleştir ya da yeni ID oluştur.
        """
        if vertex_id is not None:
            return vertex_id

        if point is None:
            return None

        # Tolerans tabanlı arama
        for existing_pt, existing_id in self._coord_to_id.items():
            if _dist(existing_pt, point) <= POINT_TOL:
                return existing_id

        # Yeni nokta → yeni ID
        new_id = self._next_id
        self._next_id += 1
        self._coord_to_id[point] = new_id
        return new_id


# ---------------------------------------------------------------------------
# EdgeGraph
# ---------------------------------------------------------------------------

class EdgeGraph:
    """
    Tüm edge'leri içeren graph.

    Attributes:
        edges           : Tüm BaseEdge nesneleri (edge_index → nesne)
        adj             : vertex_id → [EdgeNode] adjacency listesi
        isolated_closed : Kendi başına kapalı edge'ler (Circle vb.)
        orphan_edges    : Hiçbir vertex'e bağlanamayan edge'ler
        resolver        : VertexResolver (koordinat ↔ id dönüşümü)
    """

    def __init__(self):
        self.edges: Dict[int, BaseEdge] = {}
        self.adj: Dict[int, List[dict]] = defaultdict(list)
        self.isolated_closed: List[BaseEdge] = []
        self.orphan_edges: List[BaseEdge] = []
        self.resolver = VertexResolver()

    # ------------------------------------------------------------------ #
    #  Kurulum                                                             #
    # ------------------------------------------------------------------ #

    @classmethod
    def from_edges(cls, edges: List[BaseEdge]) -> "EdgeGraph":
        g = cls()
        for edge in edges:
            g._add_edge(edge)
        return g

    def _add_edge(self, edge: BaseEdge):
        self.edges[edge.edge_index] = edge

        # 1. Kendi başına kapalı mı?
        if edge.is_closed:
            self.isolated_closed.append(edge)
            return

        # 2. Vertex ID çözümle — önce Inventor'ın ID'si, yoksa koordinat
        sv = self.resolver.resolve(edge.start_vertex_id, edge.start_point)
        ev = self.resolver.resolve(edge.end_vertex_id, edge.end_point)

        if sv is None or ev is None:
            self.orphan_edges.append(edge)
            return

        # 3. Adjacency'e ekle (undirected)
        self.adj[sv].append({"neighbor": ev, "edge_index": edge.edge_index})
        self.adj[ev].append({"neighbor": sv, "edge_index": edge.edge_index})

    # ------------------------------------------------------------------ #
    #  Connected Component tespiti                                         #
    # ------------------------------------------------------------------ #

    def connected_components(self) -> List[List[int]]:
        """Vertex ID'lerine göre bağlı bileşenleri döndürür."""
        visited: Set[int] = set()
        components = []

        for node in self.adj:
            if node in visited:
                continue
            comp = []
            queue = deque([node])
            visited.add(node)

            while queue:
                cur = queue.popleft()
                comp.append(cur)
                for item in self.adj[cur]:
                    nb = item["neighbor"]
                    if nb not in visited:
                        visited.add(nb)
                        queue.append(nb)

            components.append(comp)

        return components

    def edges_in_component(self, vertex_ids: List[int]) -> List[BaseEdge]:
        """Belirli vertex'lere ait edge'leri döndürür (duplicate yok)."""
        seen_edges: Set[int] = set()
        result = []
        vid_set = set(vertex_ids)

        for vid in vertex_ids:
            for item in self.adj[vid]:
                eidx = item["edge_index"]
                if eidx not in seen_edges and item["neighbor"] in vid_set:
                    seen_edges.add(eidx)
                    result.append(self.edges[eidx])

        return result

    # ------------------------------------------------------------------ #
    #  Vertex degree analizi                                               #
    # ------------------------------------------------------------------ #

    def vertex_degrees(self) -> Dict[int, int]:
        return {vid: len(neighbors) for vid, neighbors in self.adj.items()}

    def junction_vertices(self) -> List[int]:
        """Degree > 2 olan vertex'ler — birden fazla yola ayrılan noktalar."""
        return [vid for vid, deg in self.vertex_degrees().items() if deg > 2]

    def endpoint_vertices(self) -> List[int]:
        """Degree == 1 olan vertex'ler — yolun uç noktaları."""
        return [vid for vid, deg in self.vertex_degrees().items() if deg == 1]

    # ------------------------------------------------------------------ #
    #  Debug / özet                                                        #
    # ------------------------------------------------------------------ #

    def summary(self) -> dict:
        from collections import Counter
        type_counts = Counter(e.geom_type for e in self.edges.values())
        return {
            "total_edges":       len(self.edges),
            "graph_vertices":    len(self.adj),
            "isolated_closed":   len(self.isolated_closed),
            "orphan_edges":      len(self.orphan_edges),
            "type_counts":       dict(type_counts),
            "junction_vertices": len(self.junction_vertices()),
            "endpoint_vertices": len(self.endpoint_vertices()),
        }

    def print_summary(self):
        s = self.summary()
        print("=" * 50)
        print("EdgeGraph Özeti")
        print("=" * 50)
        for k, v in s.items():
            print(f"  {k:25s}: {v}")
        print()
        if self.orphan_edges:
            print("  [UYARI] Vertex'e bağlanamayan edge'ler:")
            for e in self.orphan_edges:
                print(f"    edge_index={e.edge_index} raw_type={e.raw_type}")
        print("=" * 50)
