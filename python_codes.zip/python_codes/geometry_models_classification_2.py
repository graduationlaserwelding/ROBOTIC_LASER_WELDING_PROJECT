class BaseGeometry:
    def __init__(
        self,
        body_index,
        edge_index,
        raw_type,
        geom_type,
        start_vertex_id=None,
        end_vertex_id=None,
        connected_face_count=None
    ):
        self.body_index = body_index
        self.edge_index = edge_index
        self.raw_type = raw_type
        self.type = geom_type
        self.start_vertex_id = start_vertex_id
        self.end_vertex_id = end_vertex_id
        self.connected_face_count = connected_face_count

    def to_dict(self):
        return {
            "body_index": self.body_index,
            "edge_index": self.edge_index,
            "raw_type": self.raw_type,
            "type": self.type,
            "start_vertex_id": self.start_vertex_id,
            "end_vertex_id": self.end_vertex_id,
            "connected_face_count": self.connected_face_count
        }


class LineSegmentGeometry(BaseGeometry):
    def __init__(
        self,
        body_index,
        edge_index,
        raw_type,
        start,
        end,
        length,
        start_vertex_id=None,
        end_vertex_id=None,
        connected_face_count=None
    ):
        super().__init__(
            body_index, edge_index, raw_type, "LineSegment",
            start_vertex_id, end_vertex_id, connected_face_count
        )
        self.start = start
        self.end = end
        self.length = length

    def to_dict(self):
        data = super().to_dict()
        data.update({
            "start": self.start,
            "end": self.end,
            "length": self.length
        })
        return data


class CircleGeometry(BaseGeometry):
    def __init__(
        self,
        body_index,
        edge_index,
        raw_type,
        center,
        radius,
        normal,
        start_vertex_id=None,
        end_vertex_id=None,
        connected_face_count=None
    ):
        super().__init__(
            body_index, edge_index, raw_type, "Circle",
            start_vertex_id, end_vertex_id, connected_face_count
        )
        self.center = center
        self.radius = radius
        self.normal = normal

    def to_dict(self):
        data = super().to_dict()
        data.update({
            "center": self.center,
            "radius": self.radius,
            "normal": self.normal
        })
        return data


class ArcGeometry(BaseGeometry):
    def __init__(
        self,
        body_index,
        edge_index,
        raw_type,
        center,
        radius,
        start_point,
        end_point,
        normal,
        start_angle,
        sweep_angle,
        start_vertex_id=None,
        end_vertex_id=None,
        connected_face_count=None
    ):
        super().__init__(
            body_index, edge_index, raw_type, "Arc",
            start_vertex_id, end_vertex_id, connected_face_count
        )
        self.center = center
        self.radius = radius
        self.start_point = start_point
        self.end_point = end_point
        self.normal = normal
        self.start_angle = start_angle
        self.sweep_angle = sweep_angle

    def to_dict(self):
        data = super().to_dict()
        data.update({
            "center": self.center,
            "radius": self.radius,
            "start_point": self.start_point,
            "end_point": self.end_point,
            "normal": self.normal,
            "start_angle": self.start_angle,
            "sweep_angle": self.sweep_angle
        })
        return data


class EllipseGeometry(BaseGeometry):
    def __init__(
        self,
        body_index,
        edge_index,
        raw_type,
        center,
        major_radius,
        minor_radius,
        major_axis,
        normal,
        start_vertex_id=None,
        end_vertex_id=None,
        connected_face_count=None
    ):
        super().__init__(
            body_index, edge_index, raw_type, "Ellipse",
            start_vertex_id, end_vertex_id, connected_face_count
        )
        self.center = center
        self.major_radius = major_radius
        self.minor_radius = minor_radius
        self.major_axis = major_axis
        self.normal = normal

    def to_dict(self):
        data = super().to_dict()
        data.update({
            "center": self.center,
            "major_radius": self.major_radius,
            "minor_radius": self.minor_radius,
            "major_axis": self.major_axis,
            "normal": self.normal
        })
        return data


class SplineGeometry(BaseGeometry):
    def __init__(
        self,
        body_index,
        edge_index,
        raw_type,
        degree,
        is_closed,
        fit_points=None,
        control_points=None,
        start_vertex_id=None,
        end_vertex_id=None,
        connected_face_count=None
    ):
        super().__init__(
            body_index, edge_index, raw_type, "Spline",
            start_vertex_id, end_vertex_id, connected_face_count
        )
        self.degree = degree
        self.is_closed = is_closed
        self.fit_points = fit_points
        self.control_points = control_points

    def to_dict(self):
        data = super().to_dict()
        data.update({
            "degree": self.degree,
            "is_closed": self.is_closed,
            "fit_points": self.fit_points,
            "control_points": self.control_points
        })
        return data


class UnsupportedGeometry(BaseGeometry):
    def __init__(
        self,
        body_index,
        edge_index,
        raw_type,
        start_vertex_id=None,
        end_vertex_id=None,
        connected_face_count=None
    ):
        super().__init__(
            body_index, edge_index, raw_type, "Unsupported",
            start_vertex_id, end_vertex_id, connected_face_count
        )


        #bu kodda vertex tanımlaması yapıldı sanırım
        #yine bu kodda path_candidate_builder_2 yazıldı
        