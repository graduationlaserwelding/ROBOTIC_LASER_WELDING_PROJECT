import win32com.client

try:
    inv = win32com.client.Dispatch("Inventor.Application")
    inv.Visible = True
    print("Inventor bağlandi 🚀")
except Exception as e:
    print("Hata:", e)

# bu kodda Inventor API'sini kullanarak bir çizim açmayı denedik. 
# Eğer başarılı olursa, "Inventor bağlandi 🚀" 
# mesajı görünecektir. Eğer bir hata oluşursa, hata mesajı yazdırılacaktır. 
# Bu kodu çalıştırarak Inventor ile bağlantı kurmayı deneyebilirsiniz.
    
     
