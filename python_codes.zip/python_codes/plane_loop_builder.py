import json
# Bu da daha çok:
#line segmentlerden plane-based kapalı loop çıkarmak içindi.

TOL = 1e-6


def load_geometry(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def is_close(a, b, tol=TOL):
    return abs(a - b) <= tol


def line_planes(line):
    """
    Bir line hangi sabit koordinat düzlemlerinde yatıyor?
    Aynı anda birden fazla düzleme ait olabilir.
    """
    x1, y1, z1 = line["start"]
    x2, y2, z2 = line["end"]

    planes = []

    if is_close(x1, x2):
        planes.append(("x", round(x1, 6)))

    if is_close(y1, y2):
        planes.append(("y", round(y1, 6)))

    if is_close(z1, z2):
        planes.append(("z", round(z1, 6)))

    return planes


def get_line_segments(geometry_data):
    return [
        edge for edge in geometry_data["all_edges"]
        if edge["type"] == "LineSegment"
    ]


def build_plane_groups(lines):
    plane_groups = {}

    for line in lines:
        planes = line_planes(line)
        for plane in planes:
            plane_groups.setdefault(plane, []).append(line)

    return plane_groups


def reverse_line(line):
    new_line = dict(line)
    new_line["start"], new_line["end"] = new_line["end"], new_line["start"]
    new_line["start_vertex_id"], new_line["end_vertex_id"] = (
        new_line["end_vertex_id"],
        new_line["start_vertex_id"]
    )
    return new_line


def line_touches_path_by_vertex(line, path):
    path_start_vid = path[0]["start_vertex_id"]
    path_end_vid = path[-1]["end_vertex_id"]

    line_start_vid = line["start_vertex_id"]
    line_end_vid = line["end_vertex_id"]

    if line_start_vid is None or line_end_vid is None:
        return None
    if path_start_vid is None or path_end_vid is None:
        return None

    if line_start_vid == path_end_vid:
        return "append_forward"
    elif line_end_vid == path_end_vid:
        return "append_reverse"
    elif line_end_vid == path_start_vid:
        return "prepend_forward"
    elif line_start_vid == path_start_vid:
        return "prepend_reverse"
    else:
        return None


def build_paths_by_vertex(lines):
    unused = lines[:]
    paths = []

    while unused:
        current = unused.pop(0)
        path = [current]

        changed = True
        while changed:
            changed = False

            for i, candidate in enumerate(unused):
                mode = line_touches_path_by_vertex(candidate, path)

                if mode == "append_forward":
                    path.append(candidate)
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "append_reverse":
                    path.append(reverse_line(candidate))
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "prepend_forward":
                    path.insert(0, candidate)
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "prepend_reverse":
                    path.insert(0, reverse_line(candidate))
                    unused.pop(i)
                    changed = True
                    break

        paths.append(path)

    return paths


def is_closed_path(path):
    if not path:
        return False
    return path[0]["start_vertex_id"] == path[-1]["end_vertex_id"]


def path_length(path):
    return round(sum(seg["length"] for seg in path), 6)


if __name__ == "__main__":
    data = load_geometry("geometry_output_5.json")
    lines = get_line_segments(data)

    print("Toplam LineSegment sayısı:", len(lines))

    plane_groups = build_plane_groups(lines)

    print("\n--- Plane Groups ---")
    for plane, group_lines in sorted(plane_groups.items()):
        print(f"{plane}: {len(group_lines)} line")

    print("\n--- Plane-based Path Candidates ---")
    for plane, group_lines in sorted(plane_groups.items()):
        print(f"\nPlane {plane}:")
        paths = build_paths_by_vertex(group_lines)

        for i, path in enumerate(paths, start=1):
            print(f"  Path {i}:")
            print("    Segment sayısı:", len(path))
            print("    Kapalı mı?:", is_closed_path(path))
            print("    Toplam uzunluk:", path_length(path))
            print("    Başlangıç:", path[0]['start'])
            print("    Bitiş:", path[-1]['end'])



# bu kod şu anda line segmentlerini düzlemlere göre grupluyor ve 
# her grup için vertex bağlantılarına göre yollar oluşturuyor. 
# Her yolun kapalı olup olmadığını ve toplam uzunluğunu hesaplıyor. 
# Bu, düzlemsel döngülerin tespiti için bir temel sağlar, ancak daha 
# karmaşık durumlar için ek kontroller gerekebilir.

# Farklı geometrilerde ne yapılabilir - Düzlemsel olmayan döngüler: 
# Eğer bir döngü düzlemsel değilse, bu yöntemle tespit edilemez. 
# Bu durumda, döngünün düzlemsel olup olmadığını kontrol etmek için ek 
# geometrik analiz gerekebilir.


