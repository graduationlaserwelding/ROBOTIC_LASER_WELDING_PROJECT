# this code is defined after the path_candidate_builder_2.py code, 
# and it uses the functions defined in that code to build complex paths 
# from the geometry data extracted from the Inventor model.

import json

#Bu dosya candidate path builder.

#Burada:

#line / arc zincirleniyor
#circle tek başına kapalı path yapılıyor


from path_candidate_builder_2 import (
    build_paths_by_vertex,
    reverse_line,
    build_paths_by_vertex,
    is_closed_path
)

TOL = 1e-6


def load_geometry(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def is_close(a, b, tol=TOL):
    return abs(a - b) <= tol


def line_or_arc_planes(seg):
    """
    Bir LineSegment veya Arc hangi sabit koordinat düzlemlerinde yatıyor?
    Line için start/end kullanılır.
    Arc için start_point/end_point + center dikkate alınır.
    """
    seg_type = seg["type"]
    planes = []

    if seg_type == "LineSegment":
        x1, y1, z1 = seg["start"]
        x2, y2, z2 = seg["end"]

        if is_close(x1, x2):
            planes.append(("x", round(x1, 6)))
        if is_close(y1, y2):
            planes.append(("y", round(y1, 6)))
        if is_close(z1, z2):
            planes.append(("z", round(z1, 6)))

    elif seg_type == "Arc":
        sp = seg.get("start_point")
        ep = seg.get("end_point")
        c = seg.get("center")

        if sp and ep and c:
            xs = [sp[0], ep[0], c[0]]
            ys = [sp[1], ep[1], c[1]]
            zs = [sp[2], ep[2], c[2]]

            if is_close(xs[0], xs[1]) and is_close(xs[1], xs[2]):
                planes.append(("x", round(xs[0], 6)))
            if is_close(ys[0], ys[1]) and is_close(ys[1], ys[2]):
                planes.append(("y", round(ys[0], 6)))
            if is_close(zs[0], zs[1]) and is_close(zs[1], zs[2]):
                planes.append(("z", round(zs[0], 6)))

    return planes


def circle_plane(circle):
    """
    Circle için düzlem çıkarımı:
    normal vektörüne bakarak hangi eksene dik olduğunu bulur.
    Örn normal=(0,1,0) ise circle, y=sabit düzlemindedir.
    """
    normal = circle.get("normal")
    center = circle.get("center")

    if not normal or not center:
        return ("unknown", None)

    nx, ny, nz = normal
    cx, cy, cz = center

    if is_close(abs(nx), 1.0):
        return ("x", round(cx, 6))
    elif is_close(abs(ny), 1.0):
        return ("y", round(cy, 6))
    elif is_close(abs(nz), 1.0):
        return ("z", round(cz, 6))
    else:
        return ("unknown", None)


def get_chainable_segments(geometry_data):
    """
    Zincirlenebilir segmentler:
    - LineSegment
    - Arc
    """
    return [
        edge for edge in geometry_data["all_edges"]
        if edge["type"] in ["LineSegment", "Arc"]
    ]


def get_circles(geometry_data):
    return [
        edge for edge in geometry_data["all_edges"]
        if edge["type"] == "Circle"
    ]


def segment_start_vertex(seg):
    return seg.get("start_vertex_id")


def segment_end_vertex(seg):
    return seg.get("end_vertex_id")


def reverse_segment(seg):
    new_seg = dict(seg)

    if seg["type"] == "LineSegment":
        new_seg["start"], new_seg["end"] = new_seg["end"], new_seg["start"]

    elif seg["type"] == "Arc":
        new_seg["start_point"], new_seg["end_point"] = (
            new_seg["end_point"],
            new_seg["start_point"]
        )

    new_seg["start_vertex_id"], new_seg["end_vertex_id"] = (
        new_seg["end_vertex_id"],
        new_seg["start_vertex_id"]
    )

    return new_seg


def segment_touches_path_by_vertex(seg, path):
    path_start_vid = segment_start_vertex(path[0])
    path_end_vid = segment_end_vertex(path[-1])

    seg_start_vid = segment_start_vertex(seg)
    seg_end_vid = segment_end_vertex(seg)

    if seg_start_vid is None or seg_end_vid is None:
        return None
    if path_start_vid is None or path_end_vid is None:
        return None

    if seg_start_vid == path_end_vid:
        return "append_forward"
    elif seg_end_vid == path_end_vid:
        return "append_reverse"
    elif seg_end_vid == path_start_vid:
        return "prepend_forward"
    elif seg_start_vid == path_start_vid:
        return "prepend_reverse"
    else:
        return None


def build_paths_by_vertex_general(segments):
    unused = segments[:]
    paths = []

    while unused:
        current = unused.pop(0)
        path = [current]

        changed = True
        while changed:
            changed = False

            for i, candidate in enumerate(unused):
                mode = segment_touches_path_by_vertex(candidate, path)

                if mode == "append_forward":
                    path.append(candidate)
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "append_reverse":
                    path.append(reverse_segment(candidate))
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "prepend_forward":
                    path.insert(0, candidate)
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "prepend_reverse":
                    path.insert(0, reverse_segment(candidate))
                    unused.pop(i)
                    changed = True
                    break

        paths.append(path)

    return paths


def is_closed_general_path(path):
    if not path:
        return False
    return segment_start_vertex(path[0]) == segment_end_vertex(path[-1])


def segment_length(seg):
    if seg["type"] == "LineSegment":
        return seg.get("length", 0.0)

    elif seg["type"] == "Arc":
        radius = seg.get("radius")
        sweep = seg.get("sweep_angle")
        if radius is not None and sweep is not None:
            return abs(radius * sweep)
        return 0.0

    return 0.0


def path_length(path):
    return round(sum(segment_length(seg) for seg in path), 6)


def build_plane_groups_for_chainable(segments):
    plane_groups = {}

    for seg in segments:
        planes = line_or_arc_planes(seg)
        for plane in planes:
            plane_groups.setdefault(plane, []).append(seg)

    return plane_groups


def build_circle_candidates(circles):
    """
    Circle = tek başına kapalı path
    """
    candidates = []
    for circle in circles:
        plane = circle_plane(circle)

        candidate = {
            "path_kind": "closed_circle",
            "plane": plane,
            "is_closed": True,
            "segment_count": 1,
            "total_length": round(2 * 3.141592653589793 * circle["radius"], 6) if circle.get("radius") else None,
            "segments": [circle]
        }
        candidates.append(candidate)

    return candidates


def build_chainable_candidates_by_plane(segments):
    plane_groups = build_plane_groups_for_chainable(segments)
    candidates = []

    for plane, group_segments in sorted(plane_groups.items()):
        valid_segments = [
            s for s in group_segments
            if s.get("start_vertex_id") is not None and s.get("end_vertex_id") is not None
        ]

        if not valid_segments:
            continue

        paths = build_paths_by_vertex_general(valid_segments)

        for path in paths:
            candidate = {
                "path_kind": "mixed_curve_path",
                "plane": plane,
                "is_closed": is_closed_general_path(path),
                "segment_count": len(path),
                "total_length": path_length(path),
                "segments": path
            }
            candidates.append(candidate)

    return candidates


if __name__ == "__main__":
    data = load_geometry("geometry_output_5.json")

    chainable_segments = get_chainable_segments(data)
    circles = get_circles(data)

    print("Toplam chainable segment sayısı (Line + Arc):", len(chainable_segments))
    print("Toplam circle sayısı:", len(circles))

    chainable_candidates = build_chainable_candidates_by_plane(chainable_segments)
    circle_candidates = build_circle_candidates(circles)

    all_candidates = chainable_candidates + circle_candidates

    print("\n--- Candidate Summary ---")
    print("Chainable path candidate sayısı:", len(chainable_candidates))
    print("Circle candidate sayısı:", len(circle_candidates))
    print("Toplam candidate sayısı:", len(all_candidates))

    for i, cand in enumerate(all_candidates, start=1):
        print(f"\nCandidate {i}:")
        print("  path_kind:", cand["path_kind"])
        print("  plane:", cand["plane"])
        print("  is_closed:", cand["is_closed"])
        print("  segment_count:", cand["segment_count"])
        print("  total_length:", cand["total_length"])

        first_seg = cand["segments"][0]
        print("  first_segment_type:", first_seg["type"])

        if first_seg["type"] == "LineSegment":
            print("  first_segment_start:", first_seg["start"])
            print("  first_segment_end:", first_seg["end"])

        elif first_seg["type"] == "Arc":
            print("  first_segment_start:", first_seg.get("start_point"))
            print("  first_segment_end:", first_seg.get("end_point"))

        elif first_seg["type"] == "Circle":
            print("  circle_center:", first_seg.get("center"))
            print("  circle_radius:", first_seg.get("radius"))

    with open("complex_path_candidates.json", "w", encoding="utf-8") as f:
        json.dump(all_candidates, f, indent=4, ensure_ascii=False)

    print("\ncomplex_path_candidates.json kaydedildi.")
 


 # bu noktaya geleneye kadar şöyle yaptık diyebiliriz:
 # geometry_models_classification_2 & inventor_parça_çekme_8 & path_builder_2 yazıldı
 # topology_debug
 # plane_filter_debug
# plane_loop_builder
#  complex_path sırasıyla yazıldı. 
# 