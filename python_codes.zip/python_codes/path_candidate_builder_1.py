import json
import math


TOLERANCE = 1e-3


def point_distance(p1, p2):
    return math.sqrt(
        (p1[0] - p2[0]) ** 2 +
        (p1[1] - p2[1]) ** 2 +
        (p1[2] - p2[2]) ** 2
    )


def points_equal(p1, p2, tol=TOLERANCE):
    return point_distance(p1, p2) <= tol


def load_geometry(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_line_segments(geometry_data):
    lines = []
    for edge in geometry_data["all_edges"]:
        if edge["type"] == "LineSegment":
            lines.append(edge)
    return lines


def line_touches_path(line, path):
    """
    Bir line, path'in başına veya sonuna bağlanabiliyor mu?
    """
    line_start = line["start"]
    line_end = line["end"]

    path_start = path[0]["start"]
    path_end = path[-1]["end"]

    if points_equal(line_start, path_end):
        return "append_forward"
    elif points_equal(line_end, path_end):
        return "append_reverse"
    elif points_equal(line_end, path_start):
        return "prepend_forward"
    elif points_equal(line_start, path_start):
        return "prepend_reverse"
    else:
        return None


def reverse_line(line):
    return {
        **line,
        "start": line["end"],
        "end": line["start"]
    }


def build_paths(lines):
    unused = lines[:]
    paths = []

    while unused:
        current = unused.pop(0)
        path = [current]

        changed = True
        while changed:
            changed = False

            for i, candidate in enumerate(unused):
                mode = line_touches_path(candidate, path)

                if mode == "append_forward":
                    path.append(candidate)
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "append_reverse":
                    path.append(reverse_line(candidate))
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "prepend_forward":
                    path.insert(0, candidate)
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "prepend_reverse":
                    path.insert(0, reverse_line(candidate))
                    unused.pop(i)
                    changed = True
                    break

        paths.append(path)

    return paths


def is_closed_path(path):
    if not path:
        return False
    return points_equal(path[0]["start"], path[-1]["end"])


def path_length(path):
    total = 0.0
    for line in path:
        total += line["length"]
    return round(total, 6)


if __name__ == "__main__":
    data = load_geometry("geometry_output_4.json")
    lines = get_line_segments(data)

    print("Toplam LineSegment sayısı:", len(lines))

    paths = build_paths(lines)

    print("\n--- Path Candidate Özeti ---")
    for i, path in enumerate(paths, start=1):
        print(f"Path {i}:")
        print("  Segment sayısı:", len(path))
        print("  Kapalı mı?:", is_closed_path(path))
        print("  Toplam uzunluk:", path_length(path))
        print("  Başlangıç:", path[0]["start"])
        print("  Bitiş:", path[-1]["end"])

    # bu kod maalesef ki doğru path extraction yapamıyor. 
    # çünkü bazı line segmentler birbirlerine tam olarak bağlanmıyor olabilirler 
    # (örneğin, uç noktalar arasında küçük bir mesafe olabilir). 
    # Bu durumda, daha gelişmiş bir algoritma veya toleranslı bir eşleştirme yöntemi gerekebilir.