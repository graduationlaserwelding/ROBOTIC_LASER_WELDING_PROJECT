import json
import math
from win32com.client import gencache, CastTo
#Bu dosya extractor.

#Burada bir edge:

#LineSegment
#Circle
#Arc
#Ellipse
#Spline

#olarak sınıflanıyor.
from geometry_models_classification_2 import (
    LineSegmentGeometry,
    CircleGeometry,
    ArcGeometry,
    EllipseGeometry,
    SplineGeometry,
    UnsupportedGeometry
)


class InventorGeometryExtractor:
    def __init__(self):
        self.inv = gencache.EnsureDispatch("Inventor.Application")
        self.inv.Visible = True

    def point_to_tuple(self, pt):
        return (round(pt.X, 6), round(pt.Y, 6), round(pt.Z, 6))

    def vector_to_tuple(self, vec):
        return (round(vec.X, 6), round(vec.Y, 6), round(vec.Z, 6))

    def distance(self, p1, p2):
        return round(math.sqrt(
            (p1[0] - p2[0]) ** 2 +
            (p1[1] - p2[1]) ** 2 +
            (p1[2] - p2[2]) ** 2
        ), 6)

    def safe_get(self, obj, attr, transform=None, default=None):
        try:
            value = getattr(obj, attr)
            if transform:
                return transform(value)
            return value
        except Exception:
            return default

    def point_signature(self, point_tuple):
        # vertex eşleme için imza
        return tuple(round(c, 6) for c in point_tuple)

    def build_vertex_maps(self, body):
        """
        body.Vertices içinden vertex_id -> point ve point_signature -> vertex_id map üretir
        """
        vertex_id_to_point = {}
        point_sig_to_vertex_id = {}

        for vertex_index in range(1, body.Vertices.Count + 1):
            vertex = body.Vertices.Item(vertex_index)
            pt = self.point_to_tuple(vertex.Point)
            sig = self.point_signature(pt)

            vertex_id_to_point[vertex_index] = pt
            point_sig_to_vertex_id[sig] = vertex_index

        return vertex_id_to_point, point_sig_to_vertex_id

    def get_vertex_id_from_vertex_obj(self, vertex_obj, point_sig_to_vertex_id):
        if vertex_obj is None:
            return None

        try:
            pt = self.point_to_tuple(vertex_obj.Point)
            sig = self.point_signature(pt)
            return point_sig_to_vertex_id.get(sig)
        except Exception:
            return None

    def get_edge_topology_info(self, edge, point_sig_to_vertex_id):
        start_vertex_id = None
        end_vertex_id = None
        connected_face_count = None

        try:
            start_vertex = edge.StartVertex
            start_vertex_id = self.get_vertex_id_from_vertex_obj(start_vertex, point_sig_to_vertex_id)
        except Exception:
            start_vertex_id = None

        try:
            stop_vertex = edge.StopVertex
            end_vertex_id = self.get_vertex_id_from_vertex_obj(stop_vertex, point_sig_to_vertex_id)
        except Exception:
            end_vertex_id = None

        try:
            connected_face_count = edge.Faces.Count
        except Exception:
            connected_face_count = None

        return start_vertex_id, end_vertex_id, connected_face_count

    def extract_geometry_by_type(
        self,
        geom,
        body_index,
        edge_index,
        start_vertex_id=None,
        end_vertex_id=None,
        connected_face_count=None
    ):
        raw_type = geom.__class__.__name__

        if raw_type == "LineSegment":
            start = self.point_to_tuple(geom.StartPoint)
            end = self.point_to_tuple(geom.EndPoint)
            length = self.distance(start, end)

            return LineSegmentGeometry(
                body_index, edge_index, raw_type,
                start, end, length,
                start_vertex_id, end_vertex_id, connected_face_count
            )

        elif raw_type == "Circle":
            center = self.safe_get(geom, "Center", self.point_to_tuple)
            radius = self.safe_get(geom, "Radius", lambda x: round(x, 6))
            normal = self.safe_get(geom, "Normal", self.vector_to_tuple)

            return CircleGeometry(
                body_index, edge_index, raw_type,
                center, radius, normal,
                start_vertex_id, end_vertex_id, connected_face_count
            )

        elif raw_type in ["Arc3d", "CircularArc", "Arc2d", "Arc"]:
            return ArcGeometry(
                body_index=body_index,
                edge_index=edge_index,
                raw_type=raw_type,
                center=self.safe_get(geom, "Center", self.point_to_tuple),
                radius=self.safe_get(geom, "Radius", lambda x: round(x, 6)),
                start_point=self.safe_get(geom, "StartPoint", self.point_to_tuple),
                end_point=self.safe_get(geom, "EndPoint", self.point_to_tuple),
                normal=self.safe_get(geom, "Normal", self.vector_to_tuple),
                start_angle=self.safe_get(geom, "StartAngle", lambda x: round(x, 6)),
                sweep_angle=self.safe_get(geom, "SweepAngle", lambda x: round(x, 6)),
                start_vertex_id=start_vertex_id,
                end_vertex_id=end_vertex_id,
                connected_face_count=connected_face_count
            )

        elif raw_type in ["Ellipse", "EllipticalArc", "EllipseFull", "EllipticalFull"]:
            return EllipseGeometry(
                body_index=body_index,
                edge_index=edge_index,
                raw_type=raw_type,
                center=self.safe_get(geom, "Center", self.point_to_tuple),
                major_radius=self.safe_get(geom, "MajorRadius", lambda x: round(x, 6)),
                minor_radius=self.safe_get(geom, "MinorRadius", lambda x: round(x, 6)),
                major_axis=self.safe_get(geom, "MajorAxisVector", self.vector_to_tuple),
                normal=self.safe_get(geom, "Normal", self.vector_to_tuple),
                start_vertex_id=start_vertex_id,
                end_vertex_id=end_vertex_id,
                connected_face_count=connected_face_count
            )

        elif raw_type in ["BSplineCurve", "BSplineCurve2d", "SplineCurve", "NurbsCurve"]:
            fit_points = None
            control_points = None

            try:
                fps = geom.FitPoints
                fit_points = [self.point_to_tuple(fps.Item(i)) for i in range(1, fps.Count + 1)]
            except Exception:
                pass

            try:
                cps = geom.ControlPoints
                control_points = [self.point_to_tuple(cps.Item(i)) for i in range(1, cps.Count + 1)]
            except Exception:
                pass

            return SplineGeometry(
                body_index=body_index,
                edge_index=edge_index,
                raw_type=raw_type,
                degree=self.safe_get(geom, "Degree"),
                is_closed=self.safe_get(geom, "IsClosed"),
                fit_points=fit_points,
                control_points=control_points,
                start_vertex_id=start_vertex_id,
                end_vertex_id=end_vertex_id,
                connected_face_count=connected_face_count
            )

        else:
            return UnsupportedGeometry(
                body_index, edge_index, raw_type,
                start_vertex_id, end_vertex_id, connected_face_count
            )

    def extract_geometry_from_body(self, body, body_index):
        geometries = []

        vertex_id_to_point, point_sig_to_vertex_id = self.build_vertex_maps(body)

        for edge_index in range(1, body.Edges.Count + 1):
            edge = body.Edges.Item(edge_index)
            geom = edge.Geometry

            start_vertex_id, end_vertex_id, connected_face_count = self.get_edge_topology_info(
                edge, point_sig_to_vertex_id
            )

            geometry_obj = self.extract_geometry_by_type(
                geom,
                body_index,
                edge_index,
                start_vertex_id,
                end_vertex_id,
                connected_face_count
            )

            geometries.append(geometry_obj)

        vertices_data = [
            {"vertex_id": vid, "point": pt}
            for vid, pt in vertex_id_to_point.items()
        ]

        return geometries, vertices_data

    def extract_geometry_from_active_part(self):
        doc = self.inv.ActiveDocument
        part_doc = CastTo(doc, "PartDocument")
        comp = part_doc.ComponentDefinition

        result = {
            "document_name": doc.DisplayName,
            "body_count": comp.SurfaceBodies.Count,
            "bodies": []
        }

        all_edges = []

        for body_index in range(1, comp.SurfaceBodies.Count + 1):
            body = comp.SurfaceBodies.Item(body_index)
            edge_objects, vertices_data = self.extract_geometry_from_body(body, body_index)

            edge_dicts = [obj.to_dict() for obj in edge_objects]

            body_data = {
                "body_index": body_index,
                "face_count": body.Faces.Count,
                "edge_count": body.Edges.Count,
                "vertex_count": body.Vertices.Count,
                "vertices": vertices_data,
                "edges": edge_dicts
            }

            result["bodies"].append(body_data)
            all_edges.extend(edge_dicts)

        result["all_edges"] = all_edges
        return result


def summarize_geometry(data):
    summary = {}
    raw_summary = {}

    for edge in data["all_edges"]:
        t = edge.get("type", "Unknown")
        rt = edge.get("raw_type", "Unknown")

        summary[t] = summary.get(t, 0) + 1
        raw_summary[rt] = raw_summary.get(rt, 0) + 1

    return summary, raw_summary


if __name__ == "__main__":
    try:
        extractor = InventorGeometryExtractor()
        geometry_data = extractor.extract_geometry_from_active_part()

        print("Dosya adı:", geometry_data["document_name"])
        print("Body sayısı:", geometry_data["body_count"])

        for body in geometry_data["bodies"]:
            print(f"\nBody {body['body_index']}:")
            print("  Face sayısı:", body["face_count"])
            print("  Edge sayısı:", body["edge_count"])
            print("  Vertex sayısı:", body["vertex_count"])

        summary, raw_summary = summarize_geometry(geometry_data)

        print("\n--- Geometri özeti (genel tip) ---")
        for k, v in summary.items():
            print(f"{k}: {v}")

        print("\n--- Geometri özeti (ham Inventor tipi) ---")
        for k, v in raw_summary.items():
            print(f"{k}: {v}")

        print("\n--- İlk 10 edge örneği ---")
        for edge in geometry_data["all_edges"][:10]:
            print(edge)

        with open("geometry_output_5.json", "w", encoding="utf-8") as f:
            json.dump(geometry_data, f, indent=4, ensure_ascii=False)

        print("\ngeometry_output_5.json kaydedildi.")

    except Exception as e:
        print("Hata:", e)




        