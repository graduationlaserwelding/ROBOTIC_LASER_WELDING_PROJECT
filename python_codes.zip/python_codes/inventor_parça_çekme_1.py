import win32com.client

def edge_type_name(t):
    if t == 12290:
        return "Line"
    elif t == 12291:
        return "Circle"
    elif t == 12292:
        return "Arc"
    else:
        return f"Other ({t})"

try:
    inv = win32com.client.Dispatch("Inventor.Application")
    inv.Visible = True

    doc = inv.ActiveDocument
    print("Dosya adı:", doc.DisplayName)

    comp = doc.ComponentDefinition
    body = comp.SurfaceBodies.Item(1)

    print("Body sayısı:", comp.SurfaceBodies.Count)
    print("Face sayısı:", body.Faces.Count)
    print("Edge sayısı:", body.Edges.Count)
    print("Vertex sayısı:", body.Vertices.Count)

    print("\n--- Edge tipleri ---")
    for i in range(1, body.Edges.Count + 1):
        edge = body.Edges.Item(i)
        geom = edge.Geometry
        t = geom.GeometryType

        print("Edge", i, "->", edge_type_name(t))

except Exception as e:
    print("Hata:", e)




# bu kodda geom.GeometryType Python’dan direkt okunamıyor olabilir, 
# çünkü COM nesneleri bazen beklenmedik türlerde veri döndürebilir. 
# Bu durumda, `geom.GeometryType` değerini doğrudan okuyamıyorsanız, 
# alternatif bir yöntem deneyebilirsiniz.
