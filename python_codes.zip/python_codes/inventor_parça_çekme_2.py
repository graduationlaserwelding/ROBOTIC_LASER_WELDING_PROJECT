import win32com.client
from win32com.client import gencache, CastTo

try:
    inv = gencache.EnsureDispatch("Inventor.Application")
    inv.Visible = True

    doc = inv.ActiveDocument
    print("Dosya adı:", doc.DisplayName)

    part_doc = CastTo(doc, "PartDocument")
    comp = part_doc.ComponentDefinition
    body = comp.SurfaceBodies.Item(1)

    print("Body sayısı:", comp.SurfaceBodies.Count)
    print("Face sayısı:", body.Faces.Count)
    print("Edge sayısı:", body.Edges.Count)
    print("Vertex sayısı:", body.Vertices.Count)

    print("\n--- Edge tipleri ---")
    for i in range(1, body.Edges.Count + 1):
        edge = body.Edges.Item(i)
        geom = edge.Geometry
        geom_name = geom.__class__.__name__

        print(f"Edge {i} -> {geom_name}")

except Exception as e:
    print("Hata:", e)


    # bu kodda edge tiplerini yazdırıyoruz. 
    # Line, Arc, Circle gibi tipler olabilir. 
    # Bu bilgiyi kullanarak segmentleri sınıflandırabiliriz.
  