import json
#Bu:

#line’ları düzleme göre ayırmak için debug amaçlıydı.

TOL = 1e-6


def load_geometry(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def is_close(a, b, tol=TOL):
    return abs(a - b) <= tol


def classify_line(line):
    x1, y1, z1 = line["start"]
    x2, y2, z2 = line["end"]

    if is_close(x1, x2):
        return ("constant_x", round(x1, 6))
    elif is_close(y1, y2):
        return ("constant_y", round(y1, 6))
    elif is_close(z1, z2):
        return ("constant_z", round(z1, 6))
    else:
        return ("other", None)


if __name__ == "__main__":
    with open("geometry_output_5.json", "r", encoding="utf-8") as f:
        data = json.load(f)

    lines = [e for e in data["all_edges"] if e["type"] == "LineSegment"]

    groups = {}

    for line in lines:
        key = classify_line(line)
        groups.setdefault(key, []).append(line)

    print("--- Plane / axis groups ---")
    for key, items in groups.items():
        print(f"{key}: {len(items)} line")
        for line in items:
            print(f"  Edge {line['edge_index']}: {line['start']} -> {line['end']}")
        print()


        # bu kod bir line'ın hangi düzlemlerde yatıyor olduğunu 
        # belirler ve aynı zamanda diğer line'ları da sınıflandırır

        # "constant_x", "constant_y", "constant_z" gibi kategorilere ayırır
        # ve diğer line'ları "other" kategorisine atar

        # ancak bu kod sadece tek bir düzlemde yatıyor olan line'ları 
        # sınıflandırır. bu yüzden, bir line'ın aynı anda birden fazla 
        # düzlemde yatıyor olması durumunu göz önünde bulundurmaz. 
        # bu nedenle, bir line'ın hem "constant_x" hem de "constant_y" kategorisine ait olması mümkün değildir. 
        # bu kod, sadece tek bir düzlemde yatıyor olan line'ları sınıflandırır ve diğer line'ları "other" kategorisine atar.

        #  bu kodun üzerine plane_loop_builder.py dosyasındaki line_planes fonksiyonunu ekleyerek, 
        # bir line'ın aynı anda birden fazla düzlemde yatıyor olması durumunu da göz önünde bulundurabiliriz.