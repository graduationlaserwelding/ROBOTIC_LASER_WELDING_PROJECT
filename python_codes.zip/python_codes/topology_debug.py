import json
from collections import defaultdict, deque
#Bu:

#vertex degree
#graph yapısı

#analizi içindi.

def load_geometry(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_line_segments(geometry_data):
    return [
        edge for edge in geometry_data["all_edges"]
        if edge["type"] == "LineSegment"
    ]


def build_vertex_graph(lines):
    graph = defaultdict(list)

    for line in lines:
        sv = line["start_vertex_id"]
        ev = line["end_vertex_id"]

        if sv is None or ev is None:
            continue

        graph[sv].append({
            "neighbor": ev,
            "edge_index": line["edge_index"],
            "line": line
        })
        graph[ev].append({
            "neighbor": sv,
            "edge_index": line["edge_index"],
            "line": line
        })

    return graph


def connected_components(graph):
    visited = set()
    components = []

    for node in graph:
        if node in visited:
            continue

        comp = []
        queue = deque([node])
        visited.add(node)

        while queue:
            current = queue.popleft()
            comp.append(current)

            for item in graph[current]:
                nb = item["neighbor"]
                if nb not in visited:
                    visited.add(nb)
                    queue.append(nb)

        components.append(comp)

    return components


if __name__ == "__main__":
    data = load_geometry("geometry_output_5.json")
    lines = get_line_segments(data)
    graph = build_vertex_graph(lines)

    print("Toplam line sayısı:", len(lines))
    print("Toplam graph vertex sayısı:", len(graph))

    print("\n--- Vertex degree listesi ---")
    for vertex_id in sorted(graph.keys()):
        degree = len(graph[vertex_id])
        edge_ids = [item["edge_index"] for item in graph[vertex_id]]
        print(f"Vertex {vertex_id}: degree={degree}, edges={edge_ids}")

    comps = connected_components(graph)

    print("\n--- Connected Components ---")
    for i, comp in enumerate(comps, start=1):
        print(f"Component {i}: vertexler={sorted(comp)}")




        # bu kod birbirine bağlı line segmentleri bulup gruplamak için kullanılabilir.
        # bu kod path_candidate_builder_2 nun yanlış sonuç vermesi üzerine yazıldı. 
        # plane_loop_builder.py deki path_candidate_builder_2 fonksiyonu, birbirine bağlı line segmentleri 
        # tek bir path olarak gruplamakta sorun yaşıyordu. 
        # Bu kod ise vertex graph kullanarak birbirine bağlı line segmentleri 
        # doğru şekilde gruplamayı amaçlıyor.

        # ancak bu kod 3 boyutlu geometri için değil, 
        # sadece vertex bağlantıları üzerinden çalışır.
        #bu kodun üzerine plane_filter_debug yazıldı
