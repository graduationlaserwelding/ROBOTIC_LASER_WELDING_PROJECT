import win32com.client

try:
    inv = win32com.client.Dispatch("Inventor.Application")
    inv.Visible = True

    doc = inv.ActiveDocument
    print("Dosya adı:", doc.DisplayName)

    comp = doc.ComponentDefinition
    print("Component alındı")

    bodies = comp.SurfaceBodies
    print("Body sayısı:", bodies.Count)

except Exception as e:
    print("Hata:", e)