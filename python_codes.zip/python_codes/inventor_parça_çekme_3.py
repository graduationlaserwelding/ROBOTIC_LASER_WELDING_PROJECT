import win32com.client
from win32com.client import gencache, CastTo

try:
    inv = gencache.EnsureDispatch("Inventor.Application")
    inv.Visible = True

    doc = inv.ActiveDocument
    print("Dosya adı:", doc.DisplayName)

    part_doc = CastTo(doc, "PartDocument")
    comp = part_doc.ComponentDefinition
    body = comp.SurfaceBodies.Item(1)

    print("\n--- Edge geometrileri ---")
    for i in range(1, body.Edges.Count + 1):
        edge = body.Edges.Item(i)
        geom = edge.Geometry
        geom_name = geom.__class__.__name__

        print(f"\nEdge {i} -> {geom_name}")

        if geom_name == "LineSegment":
            sp = geom.StartPoint
            ep = geom.EndPoint
            print(f"  Start: ({sp.X:.4f}, {sp.Y:.4f}, {sp.Z:.4f})")
            print(f"  End  : ({ep.X:.4f}, {ep.Y:.4f}, {ep.Z:.4f})")

        elif geom_name == "Circle":
            center = geom.Center
            radius = geom.Radius
            print(f"  Center: ({center.X:.4f}, {center.Y:.4f}, {center.Z:.4f})")
            print(f"  Radius: {radius:.4f}")

except Exception as e:
    print("Hata:", e)

# bu kod sanki mevcut ipt dosyasına özgü gibi görünüyor, bu yüzden genel bir çözüm 
# için daha fazla hata kontrolü ve farklı geometriler için destek eklemek gerekir.    