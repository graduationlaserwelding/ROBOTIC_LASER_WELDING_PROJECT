import json
#Bu dosya candidate path builder.

#Burada:

#line / arc zincirleniyor
#circle tek başına kapalı path yapılıyor


def load_geometry(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_line_segments(geometry_data):
    return [
        edge for edge in geometry_data["all_edges"]
        if edge["type"] == "LineSegment"
    ]


def reverse_line(line):
    new_line = dict(line)
    new_line["start"], new_line["end"] = new_line["end"], new_line["start"]
    new_line["start_vertex_id"], new_line["end_vertex_id"] = (
        new_line["end_vertex_id"],
        new_line["start_vertex_id"]
    )
    return new_line


def line_touches_path_by_vertex(line, path):
    path_start_vid = path[0]["start_vertex_id"]
    path_end_vid = path[-1]["end_vertex_id"]

    line_start_vid = line["start_vertex_id"]
    line_end_vid = line["end_vertex_id"]

    if line_start_vid is None or line_end_vid is None:
        return None
    if path_start_vid is None or path_end_vid is None:
        return None

    if line_start_vid == path_end_vid:
        return "append_forward"
    elif line_end_vid == path_end_vid:
        return "append_reverse"
    elif line_end_vid == path_start_vid:
        return "prepend_forward"
    elif line_start_vid == path_start_vid:
        return "prepend_reverse"
    else:
        return None


def build_paths_by_vertex(lines):
    unused = lines[:]
    paths = []

    while unused:
        current = unused.pop(0)
        path = [current]

        changed = True
        while changed:
            changed = False

            for i, candidate in enumerate(unused):
                mode = line_touches_path_by_vertex(candidate, path)

                if mode == "append_forward":
                    path.append(candidate)
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "append_reverse":
                    path.append(reverse_line(candidate))
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "prepend_forward":
                    path.insert(0, candidate)
                    unused.pop(i)
                    changed = True
                    break

                elif mode == "prepend_reverse":
                    path.insert(0, reverse_line(candidate))
                    unused.pop(i)
                    changed = True
                    break

        paths.append(path)

    return paths


def is_closed_path(path):
    if not path:
        return False

    return path[0]["start_vertex_id"] == path[-1]["end_vertex_id"]


def path_length(path):
    return round(sum(seg["length"] for seg in path), 6)


if __name__ == "__main__":
    data = load_geometry("geometry_output_5.json")
    lines = get_line_segments(data)

    print("Toplam LineSegment sayısı:", len(lines))

    valid_lines = [ln for ln in lines if ln["start_vertex_id"] is not None and ln["end_vertex_id"] is not None]
    invalid_lines = [ln for ln in lines if ln["start_vertex_id"] is None or ln["end_vertex_id"] is None]

    print("Vertex ID’si olan LineSegment sayısı:", len(valid_lines))
    print("Vertex ID’si eksik LineSegment sayısı:", len(invalid_lines))

    paths = build_paths_by_vertex(valid_lines)

    print("\n--- Path Candidate Özeti (Vertex tabanlı) ---")
    for i, path in enumerate(paths, start=1):
        print(f"Path {i}:")
        print("  Segment sayısı:", len(path))
        print("  Kapalı mı?:", is_closed_path(path))
        print("  Toplam uzunluk:", path_length(path))
        print("  Başlangıç vertex:", path[0]["start_vertex_id"])
        print("  Bitiş vertex:", path[-1]["end_vertex_id"])
        print("  İlk nokta:", path[0]["start"])
        print("  Son nokta:", path[-1]["end"])



# problem yekın nokta vertex tespiti ile alakalı değil, vertex id’lerinin eksik olması. 
# Bu durumda vertex tabanlı birleştirme yapamıyoruz. 
# Nokta koordinatlarına göre birleştirme yapmayı deneyebiliriz ama 
# bu da hassas nokta karşılaştırması gerektirir.   